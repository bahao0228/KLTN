<?php
/**
 * File: logout.php
 * Chức năng: Đăng xuất người dùng, hủy bỏ Session và chuyển hướng về trang Login.
 * Ánh xạ từ mục 3.3.3 (Sơ đồ di chuyển tổng thể) trong tài liệu.
 */

// 1. Khởi tạo session để có quyền truy cập vào các biến session hiện tại
session_start();

// 2. Xóa tất cả các biến session đã lưu (userId, name, role...)
$_SESSION = array();

// 3. Nếu sử dụng cookie để quản lý session, hãy xóa nó để đảm bảo sạch sẽ
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// 4. Hủy bỏ hoàn toàn phiên làm việc trên Server (Bảo mật - Mục 3.1.4 c)
session_destroy();

// 5. Chuyển hướng người dùng về trang đăng nhập với một thông báo (nếu cần)
header("Location: /deha-flow/auth/login.php?logout=success");
exit();
?>