<?php
/**
 * File: login.php
 */

session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

if (is_logged_in()) {
    header('Location: /deha-flow/index.php');
    exit();
}

$error = '';

// Kiểm tra xem có phải là hành động nhấn nút Đăng nhập không
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_action'])) {
    $email = isset($_POST['email']) ? clean_input($_POST['email']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    if (empty($email) || empty($password)) {
        $error = "Vui lòng nhập đầy đủ thông tin!";
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM User WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && ($password === $user['password'])) {
                $_SESSION['userId'] = $user['userId'];
                $_SESSION['name']   = $user['name'];
                $_SESSION['role']   = $user['role']; 
                $_SESSION['dept']   = $user['department'];

                header('Location: /deha-flow/index.php');
                exit();
            } else {
                $error = "Email hoặc mật khẩu không chính xác!";
            }
        } catch (Exception $e) {
            $error = "Lỗi kết nối cơ sở dữ liệu!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập | DEHA Flow</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --deha-blue: #0056b3; --deha-green: #8cc63f; }
        body {
            height: 100vh; display: flex; align-items: center; justify-content: center;
            background: linear-gradient(135deg, var(--deha-blue) 0%, #003d8a 100%);
            font-family: 'Segoe UI', Roboto, sans-serif; margin: 0;
        }
        .login-card {
            width: 100%; max-width: 420px; background: #ffffff; border-radius: 16px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.4); overflow: hidden; border-top: 5px solid var(--deha-green);
        }
        .login-header { padding: 40px 30px 10px; text-align: center; }
        .brand-logo { max-width: 220px; height: auto; margin-bottom: 15px; }
        .system-title { color: var(--deha-blue); font-size: 0.85rem; font-weight: 700; letter-spacing: 1.5px; text-transform: uppercase; }
        .login-body { padding: 20px 45px 45px; }
        .input-group-text { background-color: #f8f9fa; border-right: none; color: var(--deha-blue); }
        .form-control { border-left: none; background-color: #f8f9fa; padding: 12px; }
        .btn-deha { background-color: var(--deha-blue); color: white; padding: 12px; font-weight: 600; border-radius: 8px; border: none; transition: all 0.3s; width: 100%; }
        .btn-deha:hover { background-color: #004494; transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0,86,179,0.3); }
    </style>
</head>
<body>

<div class="login-card">
    <div class="login-header">
        <img src="../assets/img/logo.png" alt="DEHA VIETNAM" class="brand-logo">
        <div class="system-title">Công ty Cổ phần DEHA Việt Nam</div>
    </div>

    <div class="login-body">
        <!-- CHỈ HIỆN KHI $error CÓ NỘI DUNG THỰC SỰ -->
        <?php if (!empty($error)): ?>
            <div id="login-alert" class="alert alert-danger border-0 small mb-4 shadow-sm fade show" role="alert">
                <i class="fa-solid fa-circle-exclamation me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST">
            <div class="mb-3">
                <label class="form-label small fw-bold text-muted text-uppercase">Tài khoản Email</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fa-solid fa-envelope"></i></span>
                    <input type="email" name="email" class="form-control" placeholder="example@deha-soft.com" required>
                </div>
            </div>
            
            <div class="mb-4">
                <label class="form-label small fw-bold text-muted text-uppercase">Mật khẩu nội bộ</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fa-solid fa-shield-halved"></i></span>
                    <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                </div>
            </div>

            <!-- Thêm name="login_action" để định danh hành động bấm nút -->
            <button type="submit" name="login_action" class="btn btn-deha">
                ĐĂNG NHẬP HỆ THỐNG <i class="fa-solid fa-arrow-right-to-bracket ms-2"></i>
            </button>
        </form>
    </div>

    <div class="bg-light py-3 text-center border-top">
        <small class="text-muted">Quên mật khẩu? <a href="mailto:support@deha-soft.com" class="text-decoration-none fw-bold" style="color: var(--deha-blue);">IT Support</a></small>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const alertElement = document.getElementById('login-alert');
    if (alertElement) {
        // Biến mất sau 3 giây (3000ms)
        setTimeout(function() {
            alertElement.style.transition = "opacity 0.6s ease";
            alertElement.style.opacity = "0";
            setTimeout(function() {
                alertElement.remove();
            }, 600);
        }, 3000);
    }
});
</script>
</body>
</html>