

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE TABLE `Approval` (
  `approvalId` int(11) NOT NULL,
  `proposalId` int(11) NOT NULL,
  `approverId` int(11) NOT NULL,
  `decision` varchar(50) NOT NULL,
  `approvalDate` datetime DEFAULT current_timestamp(),
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE `Comment` (
  `commentId` int(11) NOT NULL,
  `content` text NOT NULL,
  `createdBy` int(11) NOT NULL,
  `proposalId` int(11) NOT NULL,
  `createdDate` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `Notification` (
  `notificationId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `message` text NOT NULL,
  `isRead` tinyint(1) DEFAULT 0,
  `createdDate` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `Proposal` (
  `proposalId` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `status` varchar(50) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDate` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `Report` (
  `reportId` int(11) NOT NULL,
  `content` text NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Pending',
  `createdBy` int(11) NOT NULL,
  `reviewedBy` int(11) DEFAULT NULL,
  `review_comment` text DEFAULT NULL,
  `reviewedDate` datetime DEFAULT NULL,
  `createdDate` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `Task` (
  `taskId` int(11) NOT NULL,
  `taskName` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  `assignedTo` int(11) NOT NULL,
  `proposalId` int(11) DEFAULT NULL,
  `deadline` datetime DEFAULT NULL,
  `createdDate` datetime DEFAULT current_timestamp(),
  `result_text` text DEFAULT NULL,
  `result_file` varchar(255) DEFAULT NULL,
  `reviewed_by` int(11) DEFAULT NULL,
  `review_comment` text DEFAULT NULL,
  `createdBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `User` (
  `userId` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL,
  `department` varchar(100) DEFAULT NULL,
  `createdAt` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `Approval`
  ADD PRIMARY KEY (`approvalId`),
  ADD KEY `fk_approval_proposal` (`proposalId`),
  ADD KEY `fk_approval_user` (`approverId`);

ALTER TABLE `Comment`
  ADD PRIMARY KEY (`commentId`),
  ADD KEY `fk_comment_user` (`createdBy`),
  ADD KEY `fk_comment_proposal` (`proposalId`);

ALTER TABLE `Notification`
  ADD PRIMARY KEY (`notificationId`),
  ADD KEY `fk_notification_user` (`userId`);

ALTER TABLE `Proposal`
  ADD PRIMARY KEY (`proposalId`),
  ADD KEY `fk_proposal_user` (`createdBy`);

ALTER TABLE `Report`
  ADD PRIMARY KEY (`reportId`),
  ADD KEY `fk_report_creator` (`createdBy`),
  ADD KEY `fk_report_reviewer` (`reviewedBy`);

ALTER TABLE `Task`
  ADD PRIMARY KEY (`taskId`),
  ADD KEY `fk_task_user` (`assignedTo`),
  ADD KEY `fk_task_proposal` (`proposalId`),
  ADD KEY `fk_task_reviewer` (`reviewed_by`),
  ADD KEY `fk_task_creator` (`createdBy`);

--
-- Chỉ mục cho bảng `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`userId`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `Approval`
--
ALTER TABLE `Approval`
  MODIFY `approvalId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT cho bảng `Comment`
--
ALTER TABLE `Comment`
  MODIFY `commentId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `Notification`
--
ALTER TABLE `Notification`
  MODIFY `notificationId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT cho bảng `Proposal`
--
ALTER TABLE `Proposal`
  MODIFY `proposalId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT cho bảng `Report`
--
ALTER TABLE `Report`
  MODIFY `reportId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT cho bảng `Task`
--
ALTER TABLE `Task`
  MODIFY `taskId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT cho bảng `User`
--
ALTER TABLE `User`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `Approval`
--
ALTER TABLE `Approval`
  ADD CONSTRAINT `fk_approval_proposal` FOREIGN KEY (`proposalId`) REFERENCES `Proposal` (`proposalId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_approval_user` FOREIGN KEY (`approverId`) REFERENCES `User` (`userId`) ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `Comment`
--
ALTER TABLE `Comment`
  ADD CONSTRAINT `fk_comment_proposal` FOREIGN KEY (`proposalId`) REFERENCES `Proposal` (`proposalId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_comment_user` FOREIGN KEY (`createdBy`) REFERENCES `User` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `Notification`
--
ALTER TABLE `Notification`
  ADD CONSTRAINT `fk_notification_user` FOREIGN KEY (`userId`) REFERENCES `User` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `Proposal`
--
ALTER TABLE `Proposal`
  ADD CONSTRAINT `fk_proposal_user` FOREIGN KEY (`createdBy`) REFERENCES `User` (`userId`) ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `Report`
--
ALTER TABLE `Report`
  ADD CONSTRAINT `fk_report_creator` FOREIGN KEY (`createdBy`) REFERENCES `User` (`userId`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_report_reviewer` FOREIGN KEY (`reviewedBy`) REFERENCES `User` (`userId`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `Task`
--
ALTER TABLE `Task`
  ADD CONSTRAINT `fk_task_creator` FOREIGN KEY (`createdBy`) REFERENCES `User` (`userId`),
  ADD CONSTRAINT `fk_task_proposal` FOREIGN KEY (`proposalId`) REFERENCES `Proposal` (`proposalId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_task_reviewer` FOREIGN KEY (`reviewed_by`) REFERENCES `User` (`userId`),
  ADD CONSTRAINT `fk_task_user` FOREIGN KEY (`assignedTo`) REFERENCES `User` (`userId`) ON UPDATE CASCADE;
COMMIT;


