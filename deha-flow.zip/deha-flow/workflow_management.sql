-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost
-- Thời gian đã tạo: Th5 03, 2026 lúc 01:32 PM
-- Phiên bản máy phục vụ: 10.4.28-MariaDB
-- Phiên bản PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `workflow_management`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `Approval`
--

CREATE TABLE `Approval` (
  `approvalId` int(11) NOT NULL,
  `proposalId` int(11) NOT NULL,
  `approverId` int(11) NOT NULL,
  `decision` varchar(50) NOT NULL,
  `approvalDate` datetime DEFAULT current_timestamp(),
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `Comment`
--

CREATE TABLE `Comment` (
  `commentId` int(11) NOT NULL,
  `content` text NOT NULL,
  `createdBy` int(11) NOT NULL,
  `proposalId` int(11) NOT NULL,
  `createdDate` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `Notification`
--

CREATE TABLE `Notification` (
  `notificationId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `message` text NOT NULL,
  `isRead` tinyint(1) DEFAULT 0,
  `createdDate` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `Notification`
--

INSERT INTO `Notification` (`notificationId`, `userId`, `message`, `isRead`, `createdDate`) VALUES
(87, 16, 'Nhân viên Phạm Huy Hảo vừa gửi một đề xuất mới: abc', 1, '2026-05-02 21:20:44'),
(88, 16, 'Nhân viên Nguyễn Văn B vừa nộp báo cáo mới.', 1, '2026-05-02 21:25:05'),
(89, 17, 'Bạn vừa được giao một công việc mới: HTTT', 1, '2026-05-03 01:44:42'),
(90, 16, 'Nhân viên Nguyễn Văn B vừa gửi một đề xuất mới: Mua máy tính', 0, '2026-05-03 02:07:38'),
(91, 16, 'Nhân viên Nguyễn Văn B đã bắt đầu thực hiện task #8: HTTT', 0, '2026-05-03 02:11:44');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `Proposal`
--

CREATE TABLE `Proposal` (
  `proposalId` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `status` varchar(50) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDate` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `Proposal`
--

INSERT INTO `Proposal` (`proposalId`, `title`, `content`, `status`, `createdBy`, `createdDate`) VALUES
(20, 'abc', 'x', 'Pending', 16, '2026-05-02 21:20:44'),
(21, 'Mua máy tính', 'Máy cũ, hỏng', 'Pending', 17, '2026-05-03 02:07:38');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `Report`
--

CREATE TABLE `Report` (
  `reportId` int(11) NOT NULL,
  `content` text NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Pending',
  `createdBy` int(11) NOT NULL,
  `reviewedBy` int(11) DEFAULT NULL,
  `review_comment` text DEFAULT NULL,
  `reviewedDate` datetime DEFAULT NULL,
  `createdDate` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `Report`
--

INSERT INTO `Report` (`reportId`, `content`, `attachment`, `status`, `createdBy`, `reviewedBy`, `review_comment`, `reviewedDate`, `createdDate`) VALUES
(17, 'abc', '1777731905_Ảnh màn hình 2026-05-02 lúc 02.19.52.png', 'Submitted', 17, NULL, NULL, NULL, '2026-05-02 21:25:05');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `Task`
--

CREATE TABLE `Task` (
  `taskId` int(11) NOT NULL,
  `taskName` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  `assignedTo` int(11) NOT NULL,
  `proposalId` int(11) DEFAULT NULL,
  `deadline` datetime DEFAULT NULL,
  `createdDate` datetime DEFAULT current_timestamp(),
  `result_text` text DEFAULT NULL,
  `result_file` varchar(255) DEFAULT NULL,
  `reviewed_by` int(11) DEFAULT NULL,
  `review_comment` text DEFAULT NULL,
  `createdBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `Task`
--

INSERT INTO `Task` (`taskId`, `taskName`, `description`, `status`, `assignedTo`, `proposalId`, `deadline`, `createdDate`, `result_text`, `result_file`, `reviewed_by`, `review_comment`, `createdBy`) VALUES
(8, 'HTTT', '1. abc\r\n2.xzy', 'doing', 17, NULL, '2026-05-03 01:44:00', '2026-05-03 01:44:42', NULL, NULL, NULL, NULL, 16);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `User`
--

CREATE TABLE `User` (
  `userId` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL,
  `department` varchar(100) DEFAULT NULL,
  `createdAt` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `User`
--

INSERT INTO `User` (`userId`, `name`, `email`, `password`, `role`, `department`, `createdAt`) VALUES
(16, 'Phạm Huy Hảo', 'manager@deha.vn', '123456', 'Manager', 'Quản lý', '2026-05-02 16:12:30'),
(17, 'Nguyễn Văn B', 'nhanvien.b@deha.vn', '123456', 'Employee', 'Kỹ thuật', '2026-05-02 16:12:30'),
(18, 'Trần Thị C', 'nhanvien.c@deha.vn', '123456', 'Employee', 'Kỹ thuật', '2026-05-02 16:12:30'),
(19, 'Lê Văn D', 'nhanvien.d@deha.vn', '123456', 'Employee', 'Kỹ thuật', '2026-05-02 16:12:30'),
(20, 'Phạm Minh E', 'nhanvien.e@deha.vn', '123456', 'Employee', 'Thiết kế', '2026-05-02 16:12:30'),
(21, 'Hoàng Thị F', 'nhanvien.f@deha.vn', '123456', 'Employee', 'Thiết kế', '2026-05-02 16:12:30');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `Approval`
--
ALTER TABLE `Approval`
  ADD PRIMARY KEY (`approvalId`),
  ADD KEY `fk_approval_proposal` (`proposalId`),
  ADD KEY `fk_approval_user` (`approverId`);

--
-- Chỉ mục cho bảng `Comment`
--
ALTER TABLE `Comment`
  ADD PRIMARY KEY (`commentId`),
  ADD KEY `fk_comment_user` (`createdBy`),
  ADD KEY `fk_comment_proposal` (`proposalId`);

--
-- Chỉ mục cho bảng `Notification`
--
ALTER TABLE `Notification`
  ADD PRIMARY KEY (`notificationId`),
  ADD KEY `fk_notification_user` (`userId`);

--
-- Chỉ mục cho bảng `Proposal`
--
ALTER TABLE `Proposal`
  ADD PRIMARY KEY (`proposalId`),
  ADD KEY `fk_proposal_user` (`createdBy`);

--
-- Chỉ mục cho bảng `Report`
--
ALTER TABLE `Report`
  ADD PRIMARY KEY (`reportId`),
  ADD KEY `fk_report_creator` (`createdBy`),
  ADD KEY `fk_report_reviewer` (`reviewedBy`);

--
-- Chỉ mục cho bảng `Task`
--
ALTER TABLE `Task`
  ADD PRIMARY KEY (`taskId`),
  ADD KEY `fk_task_user` (`assignedTo`),
  ADD KEY `fk_task_proposal` (`proposalId`),
  ADD KEY `fk_task_reviewer` (`reviewed_by`),
  ADD KEY `fk_task_creator` (`createdBy`);

--
-- Chỉ mục cho bảng `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`userId`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `Approval`
--
ALTER TABLE `Approval`
  MODIFY `approvalId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT cho bảng `Comment`
--
ALTER TABLE `Comment`
  MODIFY `commentId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `Notification`
--
ALTER TABLE `Notification`
  MODIFY `notificationId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT cho bảng `Proposal`
--
ALTER TABLE `Proposal`
  MODIFY `proposalId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT cho bảng `Report`
--
ALTER TABLE `Report`
  MODIFY `reportId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT cho bảng `Task`
--
ALTER TABLE `Task`
  MODIFY `taskId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT cho bảng `User`
--
ALTER TABLE `User`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `Approval`
--
ALTER TABLE `Approval`
  ADD CONSTRAINT `fk_approval_proposal` FOREIGN KEY (`proposalId`) REFERENCES `Proposal` (`proposalId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_approval_user` FOREIGN KEY (`approverId`) REFERENCES `User` (`userId`) ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `Comment`
--
ALTER TABLE `Comment`
  ADD CONSTRAINT `fk_comment_proposal` FOREIGN KEY (`proposalId`) REFERENCES `Proposal` (`proposalId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_comment_user` FOREIGN KEY (`createdBy`) REFERENCES `User` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `Notification`
--
ALTER TABLE `Notification`
  ADD CONSTRAINT `fk_notification_user` FOREIGN KEY (`userId`) REFERENCES `User` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `Proposal`
--
ALTER TABLE `Proposal`
  ADD CONSTRAINT `fk_proposal_user` FOREIGN KEY (`createdBy`) REFERENCES `User` (`userId`) ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `Report`
--
ALTER TABLE `Report`
  ADD CONSTRAINT `fk_report_creator` FOREIGN KEY (`createdBy`) REFERENCES `User` (`userId`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_report_reviewer` FOREIGN KEY (`reviewedBy`) REFERENCES `User` (`userId`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `Task`
--
ALTER TABLE `Task`
  ADD CONSTRAINT `fk_task_creator` FOREIGN KEY (`createdBy`) REFERENCES `User` (`userId`),
  ADD CONSTRAINT `fk_task_proposal` FOREIGN KEY (`proposalId`) REFERENCES `Proposal` (`proposalId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_task_reviewer` FOREIGN KEY (`reviewed_by`) REFERENCES `User` (`userId`),
  ADD CONSTRAINT `fk_task_user` FOREIGN KEY (`assignedTo`) REFERENCES `User` (`userId`) ON UPDATE CASCADE;
COMMIT;


