<?php
/**
 * File: database.php
 * Chức năng: Kết nối Cơ sở dữ liệu workflow_management bằng PDO
 * Đảm bảo chuẩn bảo mật và hỗ trợ tiếng Việt (utf8mb4)
 */

// Thông số kết nối mặc định của XAMPP
$host = 'localhost';
$db   = 'workflow_management'; // Tên CSDL bạn đã tạo trên XAMPP
$user = 'root';              // User mặc định của XAMPP
$pass = '';                  // Password mặc định của XAMPP (thường để trống)
$charset = 'utf8mb4';        // Chuẩn hỗ trợ tiếng Việt tốt nhất

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

// Thiết lập các tùy chọn cho PDO
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Đẩy lỗi ra ngoại lệ để dễ debug
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // Dữ liệu trả về dạng mảng kết hợp (tên cột => giá trị)
    PDO::ATTR_EMULATE_PREPARES   => false,                  // Tăng cường bảo mật SQL Injection
];

try {
    // Khởi tạo đối tượng kết nối $pdo
    $pdo = new PDO($dsn, $user, $pass, $options);
    
    // Nếu bạn muốn kiểm tra kết nối trong giai đoạn phát triển, có thể bỏ comment dòng dưới
    // echo "Kết nối thành công đến hệ thống quản lý DEHA-Flow!"; 
    
} catch (\PDOException $e) {
    // Xử lý lỗi nếu kết nối thất bại
    // Lưu ý: Trong thực tế không nên in $e->getMessage() ra cho người dùng để tránh lộ cấu trúc DB
    die("Lỗi kết nối Cơ sở dữ liệu: " . $e->getMessage());
}
?>