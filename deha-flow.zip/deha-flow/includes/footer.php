</div> <!-- Kết thúc container mở từ header.php -->

<footer class="footer mt-auto py-3 bg-light border-top">
    <div class="container text-center">
        <span class="text-muted">© <?php echo date('Y'); ?> <strong>Công ty Cổ phần DEHA Việt Nam</strong>. Hệ thống Quản lý Quy trình Nội bộ.</span>
    </div>
</footer>

<!-- Nhúng JQuery và Bootstrap JS để xử lý các thành phần tương tác (Dropdown, Modal, Alert) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Nhúng FontAwesome để hiển thị các Icon chuyên nghiệp (Mục 3.3.3) -->
<script src="https://kit.fontawesome.com/your-code.js" crossorigin="anonymous"></script>
<!-- Nhúng JS tùy chỉnh của hệ thống -->
<script src="/deha-flow/assets/js/script.js"></script>

</body>
</html>