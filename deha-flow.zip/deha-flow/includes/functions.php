<?php
/**
 * File: functions.php
 * Chức năng: Thư viện các hàm xử lý logic nghiệp vụ dùng chung toàn hệ thống.
 * Chứa các logic thực thi từ ProposalService, TaskService và NotificationService.
 */

// 1. NHÓM HÀM XÁC THỰC & PHÂN QUYỀN (UserService logic)
// Kiểm tra người dùng đã đăng nhập chưa
function is_logged_in() {
    return isset($_SESSION['userId']);
}

// Kiểm tra quyền Quản lý (Manager)
function is_manager() {
    return (isset($_SESSION['role']) && $_SESSION['role'] === 'Manager');
}

// 2. NHÓM HÀM THÔNG BÁO (NotificationService - Mục 3.3.4 b)
// Hàm gửi thông báo tự động vào bảng Notification
function send_notification($pdo, $userId, $message) {
    $sql = "INSERT INTO Notification (userId, message, isRead, createdDate) 
            VALUES (:userId, :message, 0, NOW())";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute([
        ':userId' => $userId,
        ':message' => $message
    ]);
}

/**
 * Đếm số lượng thông báo chưa đọc của người dùng hiện tại
 */
function count_unread_notifications($pdo, $userId) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM Notification WHERE userId = ? AND isRead = 0");
    $stmt->execute([$userId]);
    return $stmt->fetchColumn();
}
// 3. NHÓM HÀM XỬ LÝ TRẠNG THÁI (Mục 3.2.3 c - Biểu đồ trạng thái)
// Chuyển đổi mã trạng thái sang Badge HTML để hiển thị đẹp trên giao diện (Usability)
function get_status_badge($status) {
    switch ($status) {
        case 'Pending':
        case 'To_Do':
            return '<span class="badge bg-warning text-dark">Chờ xử lý</span>';
        case 'Approved':
        case 'Done':
            return '<span class="badge bg-success">Đã duyệt / Xong</span>';
        case 'Rejected':
        case 'Rework':
            return '<span class="badge bg-danger">Từ chối</span>';
        case 'Doing':
            return '<span class="badge bg-primary">Đang thực hiện</span>';
        default:
            return '<span class="badge bg-secondary">' . $status . '</span>';
    }
}

// 4. NHÓM HÀM TIỆN ÍCH (Hỗ trợ Dashboard & List)
// Định dạng ngày tháng hiển thị chuẩn Việt Nam (Mục 3.1.4 d)
function format_date($date) {
    return date('d/m/Y H:i', strtotime($date));
}

// Làm sạch dữ liệu đầu vào để chống XSS (Bảo mật - Mục 3.1.4 c)
function clean_input($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// 5. LOGIC NGHIỆP VỤ ĐẶC THÙ (Ánh xạ từ Mã giả mục 3.3.4 a)
// Kiểm tra số lượng đề xuất đang chờ để hiển thị trên Dashboard (DashboardService)
function count_pending_proposals($pdo) {
    $sql = "SELECT COUNT(*) FROM Proposal WHERE status = 'Pending'";
    return $pdo->query($sql)->fetchColumn();
}
?>