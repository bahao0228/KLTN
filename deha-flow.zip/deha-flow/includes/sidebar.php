<?php
/**
 * File: sidebar.php
 * Chức năng: Menu điều hướng đồng bộ, chống tràn giao diện và cố định vị trí Badge.
 */
$full_path = $_SERVER['PHP_SELF'];
$userId = $_SESSION['userId'];
$role = $_SESSION['role'];

// Các hàm lấy dữ liệu từ hệ thống
$pendingCount = count_pending_proposals($pdo); 
$unreadNotiCount = count_unread_notifications($pdo, $userId); 

// Logic đếm số lượng Task cho Badge
$taskBadgeCount = 0;
try {
    if ($role === 'Manager') {
        $stmt_badge = $pdo->prepare("SELECT COUNT(*) FROM Task WHERE status = 'Review'");
        $stmt_badge->execute();
        $taskBadgeCount = $stmt_badge->fetchColumn();
    } else {
        $stmt_badge = $pdo->prepare("SELECT COUNT(*) FROM Task WHERE assignedTo = ? AND status = 'To_Do'");
        $stmt_badge->execute([$userId]);
        $taskBadgeCount = $stmt_badge->fetchColumn();
    }
} catch (Exception $e) { $taskBadgeCount = 0; }
?>

<style>
    /* 1. Cố định khung bao Sidebar */
    #sidebarMenu {
        background-color: #ffffff !important;
        border-right: 1px solid #e5e7eb !important;
        min-height: calc(100vh - 60px);
        padding: 0 !important; /* Loại bỏ padding mặc định gây tràn */
        z-index: 100;
    }

    #sidebarMenu .position-sticky {
        padding: 1.5rem 0.75rem !important; /* Tạo khoảng trống an toàn bên trong */
    }

    /* 2. Định dạng Menu Link */
    #sidebarMenu .nav-link {
        display: flex;
        align-items: center;
        padding: 0.75rem 1rem;
        margin-bottom: 0.25rem;
        border-radius: 10px; /* Bo góc hiện đại */
        color: #4b5563;
        font-weight: 500;
        font-size: 0.9rem;
        text-decoration: none;
        transition: all 0.2s ease;
        border: 1px solid transparent;
        width: 100%;
        box-sizing: border-box; /* Ép nội dung nằm gọn trong width */
    }

    /* 3. Icon đồng nhất */
    #sidebarMenu .menu-icon {
        width: 1.25rem;
        margin-right: 0.75rem;
        text-align: center;
        flex-shrink: 0;
        font-size: 1rem;
    }

    /* 4. Trạng thái Active (Xanh dương) - KHÔNG TRÀN BIÊN */
    #sidebarMenu .nav-link.active {
        background-color: #0d6efd !important;
        color: #ffffff !important;
        box-shadow: 0 4px 6px -1px rgba(13, 110, 253, 0.2);
    }

    #sidebarMenu .nav-link:hover:not(.active) {
        background-color: #f3f4f6;
        color: #0d6efd;
    }

    /* 5. Cố định Badge Số Đỏ - Thẳng hàng tuyệt đối */
    .badge-counter {
        margin-left: auto; /* Đẩy badge về sát bên phải của item */
        background-color: #ef4444;
        color: white;
        font-size: 0.75rem;
        font-weight: 700;
        min-width: 1.25rem;
        height: 1.25rem;
        padding: 0 0.4rem;
        border-radius: 999px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        box-shadow: 0 2px 4px rgba(239, 68, 68, 0.2);
    }

    /* 6. Tiêu đề nhóm Menu */
    .sidebar-heading {
        font-size: 0.7rem;
        text-transform: uppercase;
        font-weight: 700;
        color: #9ca3af;
        letter-spacing: 0.05em;
        padding: 1.5rem 1rem 0.5rem;
        margin: 0;
    }
</style>

<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block sidebar collapse">
    <div class="position-sticky">
        <ul class="nav flex-column">
            
            <!-- Dashboard -->
            <li class="nav-item">
                <?php $is_dashboard = (strpos($full_path, 'index.php') !== false && strpos($full_path, 'modules') === false); ?>
                <a href="/deha-flow/index.php" class="nav-link <?php echo $is_dashboard ? 'active' : ''; ?>">
                    <i class="fa-solid fa-house-chimney menu-icon"></i>
                    <span>Dashboard</span>
                </a>
            </li>

            <h6 class="sidebar-heading">Quy trình nghiệp vụ</h6>

            <!-- Đề xuất của tôi -->
            <li class="nav-item">
                <?php $is_proposal = (strpos($full_path, 'proposals/list.php') !== false || (strpos($full_path, 'proposals/detail.php') !== false && !isset($_GET['mode']))); ?>
                <a href="/deha-flow/modules/proposals/list.php" class="nav-link <?php echo $is_proposal ? 'active' : ''; ?>">
                    <i class="fa-solid fa-file-lines menu-icon"></i>
                    <span>Đề xuất của tôi</span>
                </a>
            </li>
            
            <!-- Phê duyệt (Chỉ Manager) -->
            <?php if ($role === 'Manager'): ?>
            <li class="nav-item">
                <?php $is_approve = (strpos($full_path, 'manage_approval.php') !== false || strpos($full_path, 'approve.php') !== false || (strpos($full_path, 'proposals/detail.php') !== false && isset($_GET['mode']) && $_GET['mode'] == 'admin')); ?>
                <a href="/deha-flow/modules/proposals/manage_approval.php" class="nav-link <?php echo $is_approve ? 'active' : ''; ?>">
                    <i class="fa-solid fa-file-circle-check menu-icon"></i> 
                    <span>Phê duyệt</span>
                    <?php if ($pendingCount > 0): ?>
                        <span class="badge-counter"><?php echo $pendingCount; ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <?php endif; ?>

            <!-- Công việc (Task) -->
            <li class="nav-item">
                <?php $is_task = (strpos($full_path, 'tasks/') !== false); ?>
                <a href="/deha-flow/modules/tasks/board.php" class="nav-link <?php echo $is_task ? 'active' : ''; ?>">
                    <i class="fa-solid fa-list-check menu-icon"></i> 
                    <span>Công việc (Task)</span>
                    <?php if ($taskBadgeCount > 0): ?>
                        <span class="badge-counter"><?php echo $taskBadgeCount; ?></span>
                    <?php endif; ?>
                </a>
            </li>

            <li class="nav-item">
                <?php $is_report = (strpos($full_path, 'reports/') !== false); ?>
                <a href="/deha-flow/modules/reports/my_reports.php" class="nav-link <?php echo $is_report ? 'active' : ''; ?>">
                    <i class="fa-solid fa-clipboard-list menu-icon"></i>
                    <span>Báo cáo cá nhân</span>
                </a>
            </li>

            <h6 class="sidebar-heading">Hệ thống</h6>
            
            <!-- Thông báo -->
            <li class="nav-item">
                <?php $is_noti = (strpos($full_path, 'notifications/') !== false); ?>
                <a href="/deha-flow/modules/notifications/list.php" class="nav-link <?php echo $is_noti ? 'active' : ''; ?>">
                    <i class="fa-solid fa-bell menu-icon"></i> 
                    <span>Thông báo</span>
                    <?php if ($unreadNotiCount > 0): ?>
                        <span class="badge-counter"><?php echo $unreadNotiCount; ?></span>
                    <?php endif; ?>
                </a>
            </li>
            
            <!-- Hồ sơ -->
            <li class="nav-item">
                <?php $is_profile = (strpos($full_path, 'profile/') !== false); ?>
                <a href="/deha-flow/modules/profile/view.php" class="nav-link <?php echo $is_profile ? 'active' : ''; ?>">
                    <i class="fa-solid fa-user-gear menu-icon"></i>
                    <span>Hồ sơ</span>
                </a>
            </li>
        </ul>
    </div>
</nav>