<?php
/**
 * File: header.php
 * Chức năng: Header hệ thống, sửa lỗi hiển thị thông tin người dùng.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$current_page = basename($_SERVER['PHP_SELF']);
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['userId']) && $current_page !== 'login.php') {
    header('Location: /deha-flow/auth/login.php');
    exit();
}

$user_name = $_SESSION['name'] ?? 'Người dùng';
$user_role = $_SESSION['role'] ?? 'Employee';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DEHA-Flow | Workflow System</title>
    <!-- Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="/deha-flow/assets/css/style.css">
</head>
<body>

<header class="navbar sticky-top shadow-sm">
    <!-- Phần bên trái: Logo và Tên hệ thống -->
    <a class="navbar-brand" href="/deha-flow/index.php">
        <i class="fa-solid fa-layer-group me-2" style="color: var(--deha-green);"></i>
        DEHA VIỆT NAM
    </a>

    <!-- Nút toggle cho điện thoại (ẩn trên PC) -->
    <button class="navbar-toggler d-md-none collapsed border-0" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu">
        <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Phần bên phải: Thông tin người dùng & Nút thoát -->
    <div class="navbar-right-content d-none d-md-flex">
        <div class="user-nav-info">
            <i class="fa-solid fa-circle-user"></i>
            <span><?php echo htmlspecialchars($user_name); ?></span>
            <span class="role-text">(<?php echo $user_role; ?>)</span>
        </div>
        <a class="btn-logout" href="/deha-flow/auth/logout.php">
            <i class="fa-solid fa-power-off"></i> Đăng xuất
        </a>
    </div>
</header>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar sẽ bắt đầu từ đây trong các file module -->