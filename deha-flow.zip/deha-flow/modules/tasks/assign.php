<?php
/**
 * File: modules/tasks/assign.php
 * Chức năng: Quản lý phân công công việc (Task).
 * Cập nhật: Cho phép proposalId là NULL và lưu thông tin người tạo (createdBy).
 */

// 1. Nhúng Header
require_once '../../includes/header.php';

// Bảo mật: Chỉ Quản lý mới được giao việc
if (!is_manager()) {
    header('Location: ../../index.php');
    exit();
}

$success = '';
$error = '';

// 2. Lấy dữ liệu phục vụ Form giao việc
try {
    // Lấy danh sách các đề xuất ĐÃ DUYỆT
    $stmt_proposals = $pdo->query("SELECT proposalId, title FROM Proposal WHERE status = 'Approved' ORDER BY createdDate DESC");
    $proposals = $stmt_proposals->fetchAll();

    // Lấy danh sách nhân viên
    $stmt_users = $pdo->query("SELECT userId, name, department FROM User WHERE role = 'Employee' ORDER BY name ASC");
    $users = $stmt_users->fetchAll();
} catch (Exception $e) {
    die("Lỗi tải dữ liệu: " . $e->getMessage());
}

// 3. Xử lý logic khi nhấn nút "Giao việc"
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $taskName   = clean_input($_POST['taskName']);
    $desc       = clean_input($_POST['description']);
    
    // Xử lý proposalId: Nếu để trống thì gán giá trị null
    $proposalId = !empty($_POST['proposalId']) ? $_POST['proposalId'] : null;
    $assignedTo = $_POST['assignedTo'];
    $deadline   = !empty($_POST['deadline']) ? $_POST['deadline'] : null;

    if (empty($taskName) || empty($assignedTo)) {
        $error = "Vui lòng nhập tên công việc và chọn nhân viên thực hiện!";
    } else {
        try {
            $pdo->beginTransaction();

            // INSERT vào bảng Task (Cập nhật SQL để khớp với cấu trúc bảng có createdBy)
            $sql = "INSERT INTO Task (taskName, description, status, assignedTo, proposalId, deadline, createdDate, createdBy) 
                    VALUES (:name, :desc, 'To_Do', :assignedTo, :proposalId, :deadline, NOW(), :createdBy)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':name'       => $taskName,
                ':desc'       => $desc,
                ':assignedTo' => $assignedTo,
                ':proposalId' => $proposalId,
                ':deadline'   => $deadline,
                ':createdBy'  => $_SESSION['userId'] // Lưu ID người giao việc
            ]);

            // Gửi thông báo cho nhân viên
            $msg = "Bạn vừa được giao một công việc mới: " . $taskName;
            send_notification($pdo, $assignedTo, $msg);

            $pdo->commit();
            $success = "Đã phân công công việc thành công!";
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "Lỗi hệ thống: " . $e->getMessage();
        }
    }
}
?>

<div class="row">
    <?php include '../../includes/sidebar.php'; ?>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4" style="background-color: #f8fafc; min-height: 100vh;">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4 border-bottom">
            <h1 class="h4 fw-bold mb-0 text-dark">
                <i class="fa-solid fa-user-plus text-primary me-2"></i>Giao việc mới
            </h1>
            <a href="board.php" class="btn btn-outline-secondary btn-sm rounded-pill px-3 shadow-sm">
                <i class="fa-solid fa-arrow-left me-1"></i> Quay lại bảng Task
            </a>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card shadow-sm border-0" style="border-radius: 15px;">
                    <div class="card-body p-4">
                        <?php if ($success): ?>
                            <div class="alert alert-success border-0 shadow-sm py-3 mb-4">
                                <i class="fa-solid fa-check-circle me-2"></i><?php echo $success; ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($error): ?>
                            <div class="alert alert-danger border-0 shadow-sm py-3 mb-4">
                                <i class="fa-solid fa-triangle-exclamation me-2"></i><?php echo $error; ?>
                            </div>
                        <?php endif; ?>

                        <form action="" method="POST">
                            <div class="mb-4">
                                <label class="form-label fw-bold small text-muted text-uppercase">Thuộc đề xuất nào?</label>
                                <select name="proposalId" class="form-select border-2 py-2">
                                    <option value="">-- Dự án mới (Không thuộc đề xuất nào) --</option>
                                    <?php foreach ($proposals as $p): ?>
                                        <option value="<?php echo $p['proposalId']; ?>">
                                            #<?php echo $p['proposalId']; ?> - <?php echo htmlspecialchars($p['title']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="form-text small italic">Để trống nếu đây là công việc phát sinh ngoài dự án.</div>
                            </div>

                            <div class="mb-4">
                                <label class="form-label fw-bold small text-muted text-uppercase">Tên công việc <span class="text-danger">*</span></label>
                                <input type="text" name="taskName" class="form-control border-2 py-2" placeholder="Nhập tên ngắn gọn cho công việc..." required>
                            </div>

                            <div class="mb-4">
                                <label class="form-label fw-bold small text-muted text-uppercase">Mô tả chi tiết</label>
                                <textarea name="description" class="form-control border-2" rows="3" placeholder="Hướng dẫn cụ thể cho nhân viên..."></textarea>
                            </div>

                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold small text-muted text-uppercase">Giao cho nhân viên <span class="text-danger">*</span></label>
                                    <select name="assignedTo" class="form-select border-2 py-2" required>
                                        <option value="">-- Chọn người thực hiện --</option>
                                        <?php foreach ($users as $u): ?>
                                            <option value="<?php echo $u['userId']; ?>">
                                                <?php echo htmlspecialchars($u['name']); ?> (<?php echo $u['department']; ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mt-3 mt-md-0">
                                    <label class="form-label fw-bold small text-muted text-uppercase">Hạn hoàn thành (Deadline)</label>
                                    <input type="datetime-local" name="deadline" class="form-control border-2 py-2">
                                </div>
                            </div>

                            <div class="d-grid mt-5">
                                <button type="submit" class="btn btn-primary py-3 fw-bold shadow rounded-pill text-uppercase" style="letter-spacing: 1px;">
                                    Xác nhận giao việc <i class="fa-solid fa-paper-plane ms-2"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<?php require_once '../../includes/footer.php'; ?>