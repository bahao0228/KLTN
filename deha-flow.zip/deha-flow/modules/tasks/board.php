<?php
/**
 * File: modules/tasks/board.php
 * Chức năng: Bảng Kanban quản lý công việc - Hỗ trợ hiển thị Task tự do (ProposalId là NULL).
 */
require_once '../../includes/header.php';

$userId = $_SESSION['userId'];
$role = $_SESSION['role'];

try {
    // SỬA ĐỔI: Sử dụng LEFT JOIN để không bỏ lỡ các Task có proposalId = NULL
    $query = "SELECT t.*, u.name as assignee_name, p.title as proposal_title 
              FROM Task t 
              JOIN User u ON t.assignedTo = u.userId 
              LEFT JOIN Proposal p ON t.proposalId = p.proposalId ";
    
    if ($role !== 'Manager') { 
        $query .= " WHERE t.assignedTo = :userId "; 
    }
    $query .= " ORDER BY t.deadline ASC";

    $stmt = $pdo->prepare($query);
    if ($role !== 'Manager') { 
        $stmt->bindParam(':userId', $userId); 
    }
    $stmt->execute();
    $all_tasks = $stmt->fetchAll();

    $columns = ['To_Do' => [], 'doing' => [], 'Review' => [], 'Done' => []];
    foreach ($all_tasks as $task) {
        if (isset($columns[$task['status']])) { 
            $columns[$task['status']][] = $task; 
        }
    }
} catch (Exception $e) { 
    die("Lỗi hệ thống: " . $e->getMessage()); 
}

$status_configs = [
    'To_Do'  => ['label' => 'Cần làm', 'color' => '#6c757d', 'icon' => 'fa-circle-dot'],
    'doing'  => ['label' => 'Đang làm', 'color' => '#0d6efd', 'icon' => 'fa-spinner fa-spin'],
    'Review' => ['label' => 'Chờ duyệt', 'color' => '#f59e0b', 'icon' => 'fa-eye'],
    'Done'   => ['label' => 'Hoàn thành', 'color' => '#10b981', 'icon' => 'fa-check-double']
];
?>

<style>
    .kanban-wrapper { max-width: 1300px; margin: 0 auto; }
    .kanban-column { background-color: #f1f3f5; border-radius: 12px; min-height: 80vh; width: 280px; display: flex; flex-direction: column; }
    .task-container { flex-grow: 1; overflow-y: auto; padding: 8px; max-height: 70vh; }
    .task-card { background: #fff; border-radius: 10px; border: 1px solid rgba(0,0,0,0.05); box-shadow: 0 2px 4px rgba(0,0,0,0.04); transition: all 0.2s ease; margin-bottom: 12px; }
    .task-card:hover { transform: translateY(-4px); box-shadow: 0 8px 15px rgba(0,0,0,0.1); border-color: #0d6efd; }
    .task-title { font-size: 0.95rem; font-weight: 700; color: #1e293b; line-height: 1.4; }
    .proposal-tag { font-size: 0.75rem; color: #64748b; background: #f1f5f9; padding: 2px 8px; border-radius: 4px; display: inline-block; }
</style>

<div class="container-fluid py-4" style="background-color: #f8fafc; min-height: 100vh;">
    <div class="row">
        <?php include '../../includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="kanban-wrapper">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h4 class="fw-bold text-dark mb-1"><i class="fa-solid fa-layer-group text-primary me-2"></i>Bảng công việc</h4>
                        <p class="text-muted small mb-0">Quản lý tiến độ và phê duyệt nhiệm vụ hệ thống.</p>
                    </div>
                    <?php if ($role === 'Manager'): ?>
                        <a href="assign.php" class="btn btn-primary fw-bold shadow-sm px-4 rounded-pill"><i class="fa-solid fa-plus me-1"></i>Giao việc mới</a>
                    <?php endif; ?>
                </div>

                <div class="d-flex gap-3 justify-content-center">
                    <?php foreach ($columns as $status => $tasks): ?>
                    <div class="kanban-column shadow-sm">
                        <div class="p-3 d-flex justify-content-between align-items-center border-bottom border-2" style="border-color: <?php echo $status_configs[$status]['color']; ?> !important;">
                            <span class="fw-bold small text-uppercase" style="color: <?php echo $status_configs[$status]['color']; ?>;">
                                <i class="fa-solid <?php echo $status_configs[$status]['icon']; ?> me-1"></i><?php echo $status_configs[$status]['label']; ?>
                            </span>
                            <span class="badge bg-white text-dark border rounded-pill shadow-xs"><?php echo count($tasks); ?></span>
                        </div>

                        <div class="task-container">
                            <?php foreach ($tasks as $t): ?>
                            <div class="task-card p-3">
                                <div class="mb-2">
                                    <span class="proposal-tag text-truncate d-inline-block" style="max-width: 180px;">
                                        <i class="fa-solid fa-link me-1"></i>
                                        <!-- HIỂN THỊ TÊN ĐỀ XUẤT HOẶC NHÃN TỰ DO -->
                                        <?php echo !empty($t['proposal_title']) ? htmlspecialchars($t['proposal_title']) : 'Công việc tự do'; ?>
                                    </span>
                                </div>
                                <div class="task-title mb-3"><?php echo htmlspecialchars($t['taskName']); ?></div>
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <div class="small text-danger fw-bold"><i class="fa-regular fa-calendar-check me-1"></i><?php echo date('d/m', strtotime($t['deadline'])); ?></div>
                                    <div class="small text-secondary fw-medium"><i class="fa-solid fa-circle-user text-primary me-1"></i><?php echo htmlspecialchars($t['assignee_name']); ?></div>
                                </div>

                                <div class="pt-2 border-top">
                                    <?php if ($status === 'To_Do' && $t['assignedTo'] == $userId): ?>
                                        <a href="update_status.php?id=<?php echo $t['taskId']; ?>&new=doing" class="btn btn-sm btn-primary w-100 rounded-pill py-1">Bắt đầu <i class="fa-solid fa-play ms-1"></i></a>
                                    <?php elseif ($status === 'doing' && $t['assignedTo'] == $userId): ?>
                                        <button onclick="openSubmitModal(<?php echo $t['taskId']; ?>, '<?php echo addslashes($t['taskName']); ?>')" class="btn btn-sm btn-warning w-100 rounded-pill py-1 fw-bold">Hoàn thành <i class="fa-solid fa-paper-plane ms-1"></i></button>
                                    <?php elseif ($status === 'Review' && $role === 'Manager'): ?>
                                        <button onclick="openReviewModal(<?php echo $t['taskId']; ?>, '<?php echo addslashes($t['taskName']); ?>', '<?php echo addslashes($t['result_text']); ?>', '<?php echo $t['result_file'] ?? ''; ?>')" class="btn btn-sm btn-primary w-100 rounded-pill py-1 fw-bold">Kiểm tra & Duyệt</button>
                                    <?php elseif ($status === 'Done'): ?>
                                        <div class="text-center small text-success fw-bold py-1"><i class="fa-solid fa-circle-check"></i> Đã hoàn tất</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- (Các Modal Submit và Review giữ nguyên như file gốc của bạn) -->
<div class="modal fade" id="submitTaskModal" tabindex="-1" aria-hidden="true">
    <!-- ... Giữ nguyên nội dung modal nộp bài của bạn ... -->
    <div class="modal-dialog modal-dialog-centered">
        <form action="update_status.php" method="POST" enctype="multipart/form-data" class="modal-content border-0 shadow-lg">
            <input type="hidden" name="id" id="modal_task_id">
            <input type="hidden" name="new" value="Review">
            <div class="modal-header bg-warning border-0"><h5 class="modal-title fw-bold">Nộp kết quả báo cáo</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <div class="mb-3"><label class="form-label fw-bold small">Mô tả kết quả:</label><textarea name="result_text" class="form-control" rows="4" required></textarea></div>
                <div class="mb-0"><label class="form-label fw-bold small">Tài liệu đính kèm:</label><input type="file" name="result_file" class="form-control"></div>
            </div>
            <div class="modal-footer border-0"><button type="submit" class="btn btn-warning fw-bold rounded-pill w-100 py-2 shadow-sm">Xác nhận nộp báo cáo</button></div>
        </form>
    </div>
</div>

<div class="modal fade" id="reviewTaskModal" tabindex="-1" aria-hidden="true">
    <!-- ... Giữ nguyên nội dung modal phê duyệt của bạn ... -->
    <div class="modal-dialog modal-dialog-centered">
        <form action="update_status.php" method="POST" class="modal-content border-0 shadow-lg">
            <input type="hidden" name="id" id="review_task_id">
            <input type="hidden" name="new" id="review_new_status">
            <div class="modal-header bg-primary text-white border-0"><h5 class="modal-title fw-bold">Kiểm tra kết quả</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <label class="fw-bold small text-muted text-uppercase">Báo cáo nhân viên:</label>
                <div id="review_result_text" class="p-3 bg-light rounded border mb-3 mt-1" style="white-space: pre-wrap;"></div>
                <div id="review_result_file" class="mb-4"></div>
                <label class="form-label fw-bold small">Lý do phản hồi (Nếu yêu cầu sửa):</label>
                <textarea name="review_comment" class="form-control" rows="3" placeholder="Nhập lý do duyệt hoặc yêu cầu sửa..."></textarea>
            </div>
            <div class="modal-footer border-0">
                <button type="submit" onclick="document.getElementById('review_new_status').value='To_Do'" class="btn btn-danger rounded-pill px-4 shadow-sm">Yêu cầu sửa</button>
                <button type="submit" onclick="document.getElementById('review_new_status').value='Done'" class="btn btn-success rounded-pill px-4 shadow-sm">Duyệt hoàn thành</button>
            </div>
        </form>
    </div>
</div>

<script>
// Giữ nguyên các hàm Javascript của bạn
function openSubmitModal(id, name) {
    document.getElementById('modal_task_id').value = id;
    new bootstrap.Modal(document.getElementById('submitTaskModal')).show();
}
function openReviewModal(id, name, text, file) {
    document.getElementById('review_task_id').value = id;
    document.getElementById('review_result_text').innerText = text || 'Không có mô tả.';
    const f = document.getElementById('review_result_file');
    if (file && file !== 'null' && file !== '') {
        const fileUrl = window.location.origin + '/deha-flow/' + file; 
        f.innerHTML = `
            <div class="mt-3 p-2 border rounded bg-light">
                <div class="small text-muted mb-2"><i class="fa-solid fa-paperclip me-1"></i> Tài liệu đính kèm:</div>
                <a href="${fileUrl}" target="_blank" class="btn btn-primary w-100 fw-bold">
                    <i class="fa-solid fa-file-lines me-2"></i> Xem tài liệu báo cáo
                </a>
            </div>`;
    } else {
        f.innerHTML = `<div class="mt-3 p-3 border rounded bg-light text-center"><small class="text-muted italic"><i class="fa-solid fa-circle-info me-1"></i> Nhân viên không đính kèm file.</small></div>`;
    }
    new bootstrap.Modal(document.getElementById('reviewTaskModal')).show();
}
</script>

<?php require_once '../../includes/footer.php'; ?>