<?php
/**
 * File: modules/tasks/update_status.php
 * Chức năng: Cập nhật trạng thái Task, xử lý upload báo cáo và gửi thông báo tự động.
 * Tối ưu hóa cho: macOS (XAMPP) với cơ chế tự động tạo thư mục và phân quyền.
 */
session_start();
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';

if (!is_logged_in()) { 
    header('Location: ../../auth/login.php'); 
    exit(); 
}

$taskId = $_REQUEST['id'] ?? null;
$newStatus = $_REQUEST['new'] ?? null;
$userId = $_SESSION['userId'];
$role = $_SESSION['role'];
$review_comment = $_POST['review_comment'] ?? '';

if ($taskId && $newStatus) {
    try {
        $pdo->beginTransaction();

        // 1. Lấy thông tin task hiện tại (Quan trọng để lấy createdBy và assignedTo)
        $stmt_check = $pdo->prepare("SELECT * FROM Task WHERE taskId = ?");
        $stmt_check->execute([$taskId]);
        $task = $stmt_check->fetch();

        if (!$task) { 
            exit("Task không tồn tại."); 
        }

        // 2. Thực hiện cập nhật trạng thái và dữ liệu liên quan
        
        // TRƯỜNG HỢP A: Nhân viên nộp bài (Review)
        if ($newStatus === 'Review' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $result_text = $_POST['result_text'] ?? '';
            
            // Xử lý thư mục trên macOS/XAMPP
            $base_dir = $_SERVER['DOCUMENT_ROOT'] . '/deha-flow/uploads/tasks/';
            if (!is_dir($base_dir)) {
                mkdir($base_dir, 0777, true);
                chmod($base_dir, 0777); // Đảm bảo quyền ghi trên Mac
            }

            $file_path = $task['result_file']; // Giữ file cũ nếu không có file mới
            if (!empty($_FILES['result_file']['name'])) {
                $file_name = time() . "_" . basename($_FILES["result_file"]["name"]);
                $target_file = $base_dir . $file_name;
                
                if (move_uploaded_file($_FILES["result_file"]["tmp_name"], $target_file)) {
                    $file_path = "uploads/tasks/" . $file_name;
                }
            }
            
            $stmt = $pdo->prepare("UPDATE Task SET status = 'Review', result_text = ?, result_file = ? WHERE taskId = ?");
            $stmt->execute([$result_text, $file_path, $taskId]);
        } 
        
        // TRƯỜNG HỢP B: Quản lý phê duyệt (Done) hoặc yêu cầu sửa (To_Do)
        elseif (($newStatus === 'Done' || $newStatus === 'To_Do') && $role === 'Manager') {
            $stmt = $pdo->prepare("UPDATE Task SET status = ?, reviewed_by = ?, review_comment = ? WHERE taskId = ?");
            $stmt->execute([$newStatus, $userId, $review_comment, $taskId]);
        } 
        
        // TRƯỜNG HỢP C: Các trạng thái khác (ví dụ: Bắt đầu - doing)
        else {
            $stmt = $pdo->prepare("UPDATE Task SET status = ? WHERE taskId = ?");
            $stmt->execute([$newStatus, $taskId]);
        }

        // 3. XỬ LÝ GỬI THÔNG BÁO (Fix lỗi Column 'userId' cannot be null)
        $msg = ""; 
        $receiverId = null;

        switch ($newStatus) {
            case 'doing':
                // NV bắt đầu -> Gửi cho Quản lý (người tạo task)
                $receiverId = $task['createdBy']; 
                $msg = "Nhân viên " . $_SESSION['name'] . " đã bắt đầu thực hiện task #" . $taskId . ": " . $task['taskName'];
                break;
                
            case 'Review':
                // NV nộp bài -> Gửi cho Quản lý (người tạo task)
                $receiverId = $task['createdBy'];
                $msg = "Task #" . $taskId . " đã được nộp báo cáo kết quả. Vui lòng kiểm tra.";
                break;
                
            case 'Done':
                // Quản lý duyệt -> Gửi cho Nhân viên (người được giao)
                $receiverId = $task['assignedTo'];
                $msg = "Chúc mừng! Task #" . $taskId . " của bạn đã được duyệt hoàn thành.";
                break;
                
            case 'To_Do':
                // Quản lý yêu cầu sửa -> Gửi cho Nhân viên (người được giao)
                if ($role === 'Manager') {
                    $receiverId = $task['assignedTo'];
                    $msg = "Quản lý yêu cầu sửa lại task #" . $taskId . ". Lý do: " . ($review_comment ?: "Chưa đạt yêu cầu.");
                }
                break;
        }

        // Chỉ gửi nếu xác định được người nhận và có nội dung tin nhắn
        if (!empty($receiverId) && !empty($msg) && $receiverId != $userId) {
            send_notification($pdo, $receiverId, $msg);
        }

        $pdo->commit();
        header('Location: board.php?msg=success');
        exit();

    } catch (Exception $e) { 
        $pdo->rollBack(); 
        die("Lỗi hệ thống: " . $e->getMessage()); 
    }
} else {
    header('Location: board.php?error=invalid');
    exit();
}