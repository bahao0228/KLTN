<?php
/**
 * File: manage_approval.php
 * Chức năng: Danh sách đề xuất cần phê duyệt dành cho Quản lý.
 */
require_once '../../includes/header.php';

// Bảo mật: Chỉ Quản lý mới có quyền truy cập
if (!is_manager()) { 
    header('Location: ../../index.php'); 
    exit(); 
}

$current_page = 'manage_approval.php';

// Lấy danh sách đề xuất, ưu tiên các đề xuất đang chờ (Pending) lên đầu
$stmt = $pdo->query("SELECT p.*, u.name as creator_name 
                     FROM Proposal p 
                     JOIN User u ON p.createdBy = u.userId 
                     ORDER BY (p.status = 'Pending') DESC, p.createdDate DESC");
$proposals = $stmt->fetchAll();
?>

<div class="container-fluid" style="background-color: #f8f9fa; min-height: 100vh;">
    <div class="row">
        <?php include '../../includes/sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-4 d-flex justify-content-center">
            <div style="width: 100%; max-width: 1200px;">
                
                <!-- Tiêu đề trang -->
                <div class="d-flex justify-content-between align-items-center mb-4 p-3 bg-white shadow-sm rounded-3 border-start border-success border-4">
                    <h4 class="fw-bold mb-0 text-success">
                        <i class="fa-solid fa-clipboard-check me-2"></i>Phê duyệt đề xuất 
                    </h4>
                    <span class="badge bg-success rounded-pill px-3 py-2 shadow-sm">
                        Tổng số: <?php echo count($proposals); ?>
                    </span>
                </div>

                <!-- Bảng danh sách -->
                <div class="card border-0 shadow-sm rounded-3 overflow-hidden">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light text-muted small text-uppercase fw-bold">
                                <tr>
                                    <th class="ps-4 py-3" width="8%">Mã</th>
                                    <th class="py-3 text-start" width="30%">Tiêu đề</th>
                                    <th class="py-3 text-center" width="20%">Người tạo</th>
                                    <th class="py-3 text-center" width="17%">Ngày gửi</th>
                                    <th class="py-3 text-center" width="12%">Trạng thái</th>
                                    <th class="py-3 text-center" width="13%">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($proposals as $row): ?>
                                <tr style="transition: all 0.2s;">
                                    <td class="ps-4 text-muted fw-bold">#<?php echo $row['proposalId']; ?></td>
                                    <td class="fw-bold text-dark text-start"><?php echo htmlspecialchars($row['title']); ?></td>
                                    <td class="text-center text-secondary">
                                        <i class="fa-solid fa-circle-user text-muted me-1"></i> 
                                        <?php echo htmlspecialchars($row['creator_name']); ?>
                                    </td>
                                    <td class="text-center small text-muted">
                                        <?php echo date('d/m/Y H:i', strtotime($row['createdDate'])); ?>
                                    </td>
                                    <td class="text-center">
                                        <?php echo get_status_badge($row['status']); ?>
                                    </td>
                                    <td class="text-center">
                                        <?php if ($row['status'] === 'Pending'): ?>
                                            <!-- Trang xử lý duyệt -->
                                            <a href="approve.php?id=<?php echo $row['proposalId']; ?>" 
                                               class="btn btn-success btn-sm px-3 rounded-pill shadow-sm fw-bold">
                                                Duyệt
                                            </a>
                                        <?php else: ?>
                                            <!-- Trang xem chi tiết (Thêm &mode=admin để giữ trạng thái Sidebar) -->
                                            <a href="detail.php?id=<?php echo $row['proposalId']; ?>&mode=admin" 
                                               class="btn btn-light btn-sm px-3 border rounded-pill text-muted shadow-xs">
                                                Xem
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<style>
.table-hover tbody tr:hover {
    background-color: rgba(25, 135, 84, 0.03);
}
.shadow-xs {
    box-shadow: 0 2px 4px rgba(0,0,0,0.02);
}
</style>

<?php require_once '../../includes/footer.php'; ?>