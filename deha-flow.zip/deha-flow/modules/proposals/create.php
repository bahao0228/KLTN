<?php
/**
 * File: modules/proposals/create.php
 * Chức năng: Nhân viên tạo đề xuất mới (Nghiệp vụ Đề xuất - Phê duyệt).
 * Ánh xạ: Biểu đồ hoạt động (Mục 3.2.3 b) và Mã giả (Mục 3.3.4 a).
 */

// 1. Nhúng Header (Bao gồm kết nối CSDL, Session và Functions)
require_once '../../includes/header.php';

$success = '';
$error = '';

// 2. Xử lý khi người dùng nhấn nút "Gửi đề xuất" (Trigger - Mục 3.2.1 d)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Làm sạch dữ liệu đầu vào (Bảo mật - Mục 3.1.4 c)
    $title = clean_input($_POST['title']);
    $content = clean_input($_POST['content']);
    $userId = $_SESSION['userId'];
    $status = 'Pending'; // Trạng thái mặc định khi gửi (Mục 3.2.3 c)

    if (empty($title) || empty($content)) {
        $error = "Vui lòng nhập đầy đủ tiêu đề và nội dung đề xuất!";
    } else {
        try {
            // Bắt đầu Transaction để đảm bảo tính toàn vẹn dữ liệu (Mục 3.1.4 i)
            $pdo->beginTransaction();

            // Bước 1: Lưu vào bảng Proposal (Mục 3.3.2 a)
            $sql = "INSERT INTO Proposal (title, content, status, createdBy, createdDate) 
                    VALUES (:title, :content, :status, :createdBy, NOW())";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':title' => $title,
                ':content' => $content,
                ':status' => $status,
                ':createdBy' => $userId
            ]);

            // Bước 2: Gửi thông báo cho Quản lý (NotificationService - Mục 3.3.4 b)
            // Tìm ID của người quản lý (Ví dụ: Manager cùng phòng ban hoặc Manager tổng)
            $stmt_mgr = $pdo->query("SELECT userId FROM User WHERE role = 'Manager' LIMIT 1");
            $managerId = $stmt_mgr->fetchColumn();

            if ($managerId) {
                $msg = "Nhân viên " . $_SESSION['name'] . " vừa gửi một đề xuất mới: " . $title;
                send_notification($pdo, $managerId, $msg);
            }

            $pdo->commit();
            $success = "Đề xuất của bạn đã được gửi thành công và đang chờ phê duyệt!";
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "Có lỗi xảy ra: " . $e->getMessage();
        }
    }
}
?>

<div class="row">
    <!-- Sidebar điều hướng -->
    <?php include '../../includes/sidebar.php'; ?>

    <!-- Nội dung chính Form tạo đề xuất -->
    <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2"><i class="fa-solid fa-plus-circle text-success me-2"></i>Tạo đề xuất mới</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="../../index.php">Dashboard</a></li>
                    <li class="breadcrumb-item active">Tạo đề xuất</li>
                </ol>
            </nav>
        </div>

        <div class="row">
            <div class="col-lg-8">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-4">
                        <?php if ($success): ?>
                            <div class="alert alert-success border-0 shadow-sm mb-4">
                                <i class="fa-solid fa-check-circle me-2"></i><?php echo $success; ?>
                                <br><a href="list.php" class="alert-link small">Xem danh sách đề xuất của bạn →</a>
                            </div>
                        <?php endif; ?>

                        <?php if ($error): ?>
                            <div class="alert alert-danger border-0 shadow-sm mb-4">
                                <i class="fa-solid fa-triangle-exclamation me-2"></i><?php echo $error; ?>
                            </div>
                        <?php endif; ?>

                        <form action="" method="POST">
                            <div class="mb-4">
                                <label class="form-label fw-bold small text-uppercase text-muted">Tiêu đề đề xuất</label>
                                <input type="text" name="title" class="form-control form-control-lg" 
                                       placeholder="Ví dụ: Đề xuất mua máy tính mới, Xin nghỉ phép..." required>
                                <div class="form-text">Tóm tắt ngắn gọn nhu cầu của bạn.</div>
                            </div>

                            <div class="mb-4">
                                <label class="form-label fw-bold small text-uppercase text-muted">Nội dung chi tiết</label>
                                <textarea name="content" class="form-control" rows="8" 
                                          placeholder="Mô tả chi tiết lý do, thời gian, kinh phí (nếu có)..." required></textarea>
                            </div>

                            <div class="d-flex justify-content-between align-items-center border-top pt-4">
                                <a href="list.php" class="btn btn-light px-4">
                                    <i class="fa-solid fa-arrow-left me-2"></i>Quay lại
                                </a>
                                <button type="submit" class="btn btn-primary px-5 shadow">
                                    Gửi đề xuất ngay <i class="fa-solid fa-paper-plane ms-2"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Panel hướng dẫn bên cạnh (Usability - Mục 3.1.4 d) -->
            <div class="col-lg-4">
                <div class="card border-0 bg-primary text-white shadow-sm p-3">
                    <div class="card-body">
                        <h5 class="fw-bold mb-3"><i class="fa-solid fa-circle-info me-2"></i>Hướng dẫn</h5>
                        <ul class="small opacity-75 list-unstyled">
                            <li class="mb-3"><i class="fa-solid fa-check me-2"></i>Đề xuất sau khi gửi sẽ chuyển sang trạng thái <strong>Chờ duyệt</strong>.</li>
                            <li class="mb-3"><i class="fa-solid fa-check me-2"></i>Quản lý sẽ nhận được thông báo ngay lập tức để xử lý.</li>
                            <li><i class="fa-solid fa-check me-2"></i>Bạn có thể theo dõi trạng thái đề xuất tại trang danh sách.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// 3. Nhúng Footer
require_once '../../includes/footer.php';
?>