<?php
/**
 * File: edit.php
 * Chức năng: Chỉnh sửa đề xuất và quay về Dashboard chính kèm thông báo.
 */

require_once '../../includes/header.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?? 0;
$userId = $_SESSION['userId'];

// 1. Lấy thông tin cũ
$stmt = $pdo->prepare("SELECT * FROM Proposal WHERE proposalId = ? AND createdBy = ? AND status = 'Pending'");
$stmt->execute([$id, $userId]);
$p = $stmt->fetch();

if (!$p) {
    echo "<div class='alert alert-warning m-4'>Không tìm thấy đề xuất hoặc đề xuất đã được xử lý.</div>";
    echo "</main></div></div>"; require_once '../../includes/footer.php'; exit;
}

// 2. Xử lý khi nhấn "Lưu thay đổi"
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $content = $_POST['content'] ?? '';

    try {
        // Cập nhật dữ liệu
        $update = $pdo->prepare("UPDATE Proposal SET title = ?, content = ? WHERE proposalId = ? AND createdBy = ?");
        $update->execute([$title, $content, $id, $userId]);

        // ĐIỀU HƯỚNG VỀ DASHBOARD kèm thông báo thành công
        header("Location: ../../index.php?msg=updated");
        exit;
    } catch (Exception $e) {
        $error = "Lỗi cập nhật CSDL: " . $e->getMessage();
    }
}

$noi_dung_cu = $p['content'] ?? '';
?>

<div class="row">
    <?php include '../../includes/sidebar.php'; ?>

    <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="pt-3 pb-2 mb-4 border-bottom">
            <h1 class="h3 fw-bold">Chỉnh sửa đề xuất #<?php echo $id; ?></h1>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger shadow-sm border-0 mb-4">
                <i class="fa-solid fa-circle-exclamation me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>

        <div class="card border-0 shadow-sm p-4 mb-5">
            <form method="POST">
                <div class="mb-4">
                    <label class="form-label fw-bold text-muted small text-uppercase">Tiêu đề</label>
                    <input type="text" name="title" class="form-control" 
                           value="<?php echo htmlspecialchars($p['title']); ?>" required>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold text-muted small text-uppercase">Nội dung chi tiết</label>
                    <textarea name="content" class="form-control" rows="12" 
                              required><?php echo htmlspecialchars($noi_dung_cu); ?></textarea>
                </div>

                <div class="text-end border-top pt-3">
                    <a href="javascript:history.back()" class="btn btn-light border fw-bold px-4 me-2">Hủy bỏ</a>
                    <button type="submit" class="btn btn-primary fw-bold px-5 shadow">Lưu thay đổi</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php 
echo '</main></div></div>';
require_once '../../includes/footer.php'; 
?>