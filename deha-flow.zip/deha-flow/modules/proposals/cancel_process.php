<?php
/**
 * File: cancel_process.php
 * Chức năng: Xử lý hủy đề xuất và điều hướng về Dashboard kèm thông báo.
 */

require_once '../../includes/header.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?? 0;
$userId = $_SESSION['userId'];

// Chỉ thực hiện xóa nếu đề xuất thuộc về người dùng và chưa được duyệt (Pending)
$stmt = $pdo->prepare("DELETE FROM Proposal WHERE proposalId = ? AND createdBy = ? AND status = 'Pending'");
$stmt->execute([$id, $userId]);

// Quay lại Dashboard chính kèm thông báo đã hủy
header("Location: ../../index.php?msg=cancelled");
exit;