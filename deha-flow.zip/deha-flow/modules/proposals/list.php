<?php
require_once '../../includes/header.php';
$userId = $_SESSION['userId'];
$current_page = 'list.php';

$stmt = $pdo->prepare("SELECT * FROM Proposal WHERE createdBy = ? ORDER BY createdDate DESC");
$stmt->execute([$userId]);
$proposals = $stmt->fetchAll();
?>

<div class="container-fluid">
    <div class="row">
        <?php include '../../includes/sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-4 d-flex justify-content-center">
            <div style="width: 100%; max-width: 1100px;">
                
                <!-- Tiêu đề và Nút bấm -->
                <div class="d-flex justify-content-between align-items-center mb-4 p-3 bg-white shadow-sm rounded-3">
                    <h4 class="fw-bold mb-0 text-dark">
                        <i class="fa-solid fa-receipt text-primary me-2"></i>Danh sách đề xuất của tôi
                    </h4>
                    <a href="create.php" class="btn btn-primary px-4 fw-bold shadow-sm rounded-pill">
                        <i class="fa-solid fa-plus-circle me-1"></i> Tạo đề xuất mới
                    </a>
                </div>

                <!-- Card chứa Bảng -->
                <div class="card border-0 shadow-sm rounded-3 overflow-hidden">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light text-muted small text-uppercase fw-bold">
                                <tr>
                                    <th class="ps-4 py-3" width="10%">Mã số</th>
                                    <th class="py-3" width="40%">Tiêu đề nội dung</th>
                                    <th class="py-3 text-center" width="20%">Ngày gửi</th>
                                    <th class="py-3 text-center" width="15%">Trạng thái</th>
                                    <th class="py-3 text-center" width="15%">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($proposals): foreach ($proposals as $row): ?>
                                <tr style="transition: all 0.2s;">
                                    <td class="ps-4 fw-bold text-muted">#<?php echo $row['proposalId']; ?></td>
                                    <td>
                                        <div class="fw-bold text-dark mb-0"><?php echo htmlspecialchars($row['title']); ?></div>
                                        <small class="text-muted d-block text-truncate" style="max-width: 300px;">
                                            <?php echo htmlspecialchars($row['content']); ?>
                                        </small>
                                    </td>
                                    <td class="text-center small text-muted"><?php echo date('d/m/Y H:i', strtotime($row['createdDate'])); ?></td>
                                    <td class="text-center"><?php echo get_status_badge($row['status']); ?></td>
                                    <td class="text-center">
                                        <a href="detail.php?id=<?php echo $row['proposalId']; ?>" class="btn btn-outline-primary btn-sm px-3 rounded-pill">
                                            Chi tiết
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; else: ?>
                                <tr><td colspan="5" class="text-center py-5 text-muted italic">Bạn chưa khởi tạo đề xuất nào.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>