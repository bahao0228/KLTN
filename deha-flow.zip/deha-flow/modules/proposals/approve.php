<?php
/**
 * File: modules/proposals/approve.php
 * Chức năng: Quản lý xử lý đề xuất (Duyệt/Từ chối) kèm lý do phản hồi.
 * Cập nhật: Đã hỗ trợ lưu cột 'comment' vào bảng Approval.
 */

// 1. Nhúng Header
require_once '../../includes/header.php';

// Bảo mật: Chỉ Quản lý mới có quyền truy cập trang này
if (!is_manager()) {
    header('Location: ../../index.php');
    exit();
}

$proposalId = $_GET['id'] ?? null;
$success = '';
$error = '';

// Lấy thông tin chi tiết đề xuất để hiển thị
if ($proposalId) {
    $stmt = $pdo->prepare("SELECT p.*, u.name as creator_name FROM Proposal p JOIN User u ON p.createdBy = u.userId WHERE p.proposalId = ?");
    $stmt->execute([$proposalId]);
    $proposal = $stmt->fetch();

    if (!$proposal) {
        die("Không tìm thấy đề xuất!");
    }
}

// 2. Xử lý logic khi gửi Form phê duyệt
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action']; // 'Approved' hoặc 'Rejected'
    $reason = $_POST['admin_comment'] ?? ''; // Lý do phản hồi
    $approverId = $_SESSION['userId'];

    try {
        $pdo->beginTransaction();

        // Bước 1: Cập nhật trạng thái đề xuất
        $stmt_update = $pdo->prepare("UPDATE Proposal SET status = ? WHERE proposalId = ?");
        $stmt_update->execute([$action, $proposalId]);

        // Bước 2: Lưu vào bảng Approval (Cột 'comment' bạn vừa thêm)
        $stmt_approve = $pdo->prepare("INSERT INTO Approval (proposalId, approverId, decision, approvalDate, comment) VALUES (?, ?, ?, NOW(), ?)");
        $stmt_approve->execute([$proposalId, $approverId, $action, $reason]);

        // Bước 3: Gửi thông báo cho nhân viên
        $status_text = ($action === 'Approved') ? "đã được DUYỆT" : "đã bị TỪ CHỐI";
        $msg = "Đề xuất '#$proposalId - {$proposal['title']}' của bạn $status_text";
        
        if (!empty($reason)) {
            $msg .= ". Nội dung phản hồi: $reason";
        }
        
        send_notification($pdo, $proposal['createdBy'], $msg);

        $pdo->commit();
        $success = "Hệ thống đã ghi nhận kết quả phê duyệt thành công!";
        
        // Quay lại danh sách quản lý
        header("refresh:1.5; url=manage_approval.php");
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Lỗi xử lý dữ liệu: " . $e->getMessage();
    }
}
?>

<div class="container-fluid">
    <div class="row">
        <?php include '../../includes/sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-4 d-flex flex-column align-items-center">
            <div style="width: 100%; max-width: 800px;">
                
                <div class="d-flex align-items-center mb-3">
                    <a href="manage_approval.php" class="btn btn-outline-secondary btn-sm rounded-circle me-3 shadow-sm">
                        <i class="fa-solid fa-arrow-left"></i>
                    </a>
                    <h1 class="h3 fw-bold mb-0">Xử lý đề xuất</h1>
                </div>

                <?php if ($success): ?>
                    <div class="alert alert-success border-0 shadow-sm rounded-3 py-3">
                        <i class="fa-solid fa-circle-check fa-lg me-2"></i> <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger border-0 shadow-sm rounded-3 py-3">
                        <i class="fa-solid fa-triangle-exclamation fa-lg me-2"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>

                <div class="card shadow-sm border-0 rounded-4 overflow-hidden mb-5">
                    <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
                        <h5 class="mb-0 fw-bold text-dark">Mã phiếu: #<?php echo $proposalId; ?></h5>
                        <span class="badge bg-light text-primary border px-3 py-2 rounded-pill">Đang chờ xử lý</span>
                    </div>
                    
                    <div class="card-body p-4">
                        <div class="row mb-4">
                            <div class="col-md-6 border-end">
                                <label class="text-muted small text-uppercase fw-bold mb-1">Nhân viên gửi:</label>
                                <p class="fw-bold text-primary mb-0" style="font-size: 1.1rem;">
                                    <i class="fa-solid fa-circle-user me-1"></i> <?php echo htmlspecialchars($proposal['creator_name']); ?>
                                </p>
                            </div>
                            <div class="col-md-6 ps-md-4">
                                <label class="text-muted small text-uppercase fw-bold mb-1">Thời gian gửi:</label>
                                <p class="mb-0 text-dark fw-medium">
                                    <i class="fa-regular fa-clock me-1 text-muted"></i> <?php echo date('d/m/Y H:i', strtotime($proposal['createdDate'])); ?>
                                </p>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label class="text-muted small text-uppercase fw-bold mb-1">Chủ đề đề xuất:</label>
                            <h5 class="fw-bold text-dark border-start border-primary border-4 ps-3 py-1">
                                <?php echo htmlspecialchars($proposal['title']); ?>
                            </h5>
                        </div>

                        <div class="mb-4 p-3 bg-light rounded-3 border">
                            <label class="text-muted small text-uppercase fw-bold d-block mb-2">Chi tiết nội dung:</label>
                            <div class="p-2 bg-white rounded-2 border border-light-subtle" style="white-space: pre-line; line-height: 1.6; min-height: 100px;">
                                <?php echo htmlspecialchars($proposal['content']); ?>
                            </div>
                        </div>

                        <?php if ($proposal['status'] === 'Pending'): ?>
                        <form action="" method="POST" id="approvalForm" class="border-top pt-4">
                            <!-- Phần nhập lý do phản hồi -->
                            <div class="mb-4">
                                <label for="admin_comment" class="form-label fw-bold text-dark small text-uppercase">
                                    <i class="fa-solid fa-pen-to-square me-1"></i> Phản hồi của người duyệt (Yêu cầu nếu từ chối)
                                </label>
                                <textarea name="admin_comment" id="admin_comment" class="form-control shadow-sm" rows="4" 
                                          placeholder="Vui lòng nhập lý do nếu bạn từ chối hoặc để lại lời nhắn cho nhân viên..."></textarea>
                            </div>

                            <div class="d-flex gap-3 justify-content-between align-items-center">
                                <button type="submit" name="action" value="Rejected" class="btn btn-outline-danger px-4 rounded-pill fw-bold" onclick="return validateRejection()">
                                    <i class="fa-solid fa-ban me-2"></i> Từ chối
                                </button>
                                <button type="submit" name="action" value="Approved" class="btn btn-success px-5 rounded-pill shadow-sm fw-bold" onclick="return confirm('Xác nhận PHÊ DUYỆT đề xuất này?')">
                                    <i class="fa-solid fa-check-double me-2"></i> Duyệt đề xuất
                                </button>
                            </div>
                        </form>
                        <?php else: ?>
                            <div class="alert alert-secondary text-center rounded-pill py-3">
                                <i class="fa-solid fa-lock me-2"></i> Phiếu này đã được xử lý với kết quả: 
                                <strong><?php echo get_status_badge($proposal['status']); ?></strong>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
/**
 * Chặn gửi form nếu từ chối mà chưa nhập lý do
 */
function validateRejection() {
    const comment = document.getElementById('admin_comment').value.trim();
    if (comment.length < 5) {
        alert("⚠️ Thông báo: Bạn cần nhập lý do từ chối cụ thể (tối thiểu 5 ký tự) để nhân viên có thể cải thiện đề xuất!");
        document.getElementById('admin_comment').style.borderColor = "#dc3545";
        document.getElementById('admin_comment').focus();
        return false;
    }
    return confirm("Bạn chắc chắn muốn TỪ CHỐI đề xuất này?");
}
</script>

<?php require_once '../../includes/footer.php'; ?>