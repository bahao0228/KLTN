<?php
/**
 * File: detail.php
 * Chức năng: Xem chi tiết đề xuất, hỗ trợ Sửa/Hủy (Chủ sở hữu) và Duyệt (Quản lý cấp trên).
 */

// 1. Nhúng Header
require_once '../../includes/header.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?? 0;
$userId = $_SESSION['userId'];
$role = $_SESSION['role'];

// 2. Lấy dữ liệu đề xuất
$stmt = $pdo->prepare("SELECT p.*, u.name as creator_name FROM Proposal p 
                       JOIN User u ON p.createdBy = u.userId 
                       WHERE p.proposalId = ?");
$stmt->execute([$id]);
$p = $stmt->fetch();

// 3. Kiểm tra quyền xem
if (!$p || ($role !== 'Manager' && $p['createdBy'] != $userId)) {
    echo "<div class='alert alert-danger m-4'>
            <i class='fa-solid fa-triangle-exclamation me-2'></i>
            Bạn không có quyền xem đề xuất này hoặc dữ liệu không tồn tại.
          </div>";
    require_once '../../includes/footer.php';
    exit;
}

$isPending = ($p['status'] === 'Pending');
// Kiểm tra xem người đang đăng nhập có phải là người tạo ra đề xuất này không
$isOwner = ($p['createdBy'] == $userId);

$noi_dung_de_xuat = $p['description'] ?? $p['content'] ?? 'Không có nội dung mô tả.';
?>

<div class="row">
    <?php include '../../includes/sidebar.php'; ?>

    <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pb-5">
        <div class="d-flex justify-content-between align-items-center pt-3 pb-2 mb-4 border-bottom">
            <h1 class="h3 fw-bold">
                <i class="fa-solid fa-file-circle-info text-primary me-2"></i>Chi tiết đề xuất #<?php echo $id; ?>
            </h1>
            <a href="javascript:history.back()" class="btn btn-outline-secondary fw-bold shadow-sm">
                <i class="fa-solid fa-arrow-left me-1"></i> Quay lại
            </a>
        </div>

        <div class="row">
            <!-- Cột trái: Nội dung chi tiết -->
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-white py-3">
                        <h6 class="mb-0 fw-bold small text-uppercase text-muted">Nội dung đề xuất</h6>
                    </div>
                    <div class="card-body p-4">
                        <div class="mb-4">
                            <label class="text-muted small fw-bold text-uppercase">Tiêu đề:</label>
                            <h4 class="fw-bold text-dark mt-1"><?php echo htmlspecialchars($p['title']); ?></h4>
                        </div>
                        <hr>
                        <div class="mb-2">
                            <label class="text-muted small fw-bold text-uppercase">Mô tả công việc:</label>
                            <div class="mt-2 p-3 bg-light rounded border shadow-sm" style="white-space: pre-wrap; min-height: 250px; line-height: 1.6; color: #333;">
                                <?php echo htmlspecialchars($noi_dung_de_xuat); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Cột phải: Thông tin trạng thái & Thao tác -->
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-white py-3 fw-bold small text-uppercase text-muted">Thông tin hệ thống</div>
                    <div class="card-body p-4">
                        <div class="mb-3">
                            <label class="text-muted small d-block mb-1">Người lập:</label>
                            <span class="fw-bold text-primary">
                                <i class="fa-solid fa-user-pen me-1"></i> <?php echo htmlspecialchars($p['creator_name']); ?>
                            </span>
                        </div>
                        <div class="mb-4">
                            <label class="text-muted small d-block mb-1">Ngày gửi:</label>
                            <span class="fw-bold text-dark">
                                <i class="fa-solid fa-calendar-day me-1"></i> <?php echo date('d/m/Y H:i', strtotime($p['createdDate'])); ?>
                            </span>
                        </div>
                        
                        <hr>
                        
                        <div class="text-center py-2 mb-4">
                            <?php if($p['status'] === 'Pending'): ?>
                                <div class="badge bg-warning text-dark p-3 w-100 rounded shadow-sm">
                                    <i class="fa-solid fa-clock-rotate-left me-2"></i>CHỜ PHÊ DUYỆT
                                </div>
                            <?php elseif($p['status'] === 'Approved'): ?>
                                <div class="badge bg-success p-3 w-100 rounded shadow-sm">
                                    <i class="fa-solid fa-circle-check me-2"></i>ĐÃ PHÊ DUYỆT
                                </div>
                            <?php else: ?>
                                <div class="badge bg-danger p-3 w-100 rounded shadow-sm">
                                    <i class="fa-solid fa-circle-xmark me-2"></i>TỪ CHỐI / HỦY
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="d-grid gap-2">
                            <?php if ($isPending): ?>
                                <?php if ($isOwner): ?>
                                    <!-- CHỦ SỞ HỮU (Dù là QL hay NV): Hiện Sửa/Hủy -->
                                    <a href="edit.php?id=<?php echo $id; ?>" class="btn btn-primary fw-bold shadow-sm">
                                        <i class="fa-solid fa-pen-to-square me-2"></i> Chỉnh sửa đề xuất
                                    </a>
                                    <button onclick="handleCancel(<?php echo $id; ?>)" class="btn btn-outline-danger fw-bold">
                                        <i class="fa-solid fa-trash-can me-2"></i> Hủy đề xuất này
                                    </button>
                                <?php elseif ($role === 'Manager'): ?>
                                    <!-- QUẢN LÝ CẤP TRÊN (Duyệt cho người khác) -->
                                    <a href="approve.php?id=<?php echo $id; ?>" class="btn btn-success fw-bold shadow-sm">
                                        <i class="fa-solid fa-check me-2"></i> Đi đến phê duyệt
                                    </a>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="alert alert-secondary mb-0 small text-center border-0 rounded-3">
                                    <i class="fa-solid fa-lock me-1"></i> Trạng thái đã chốt, không thể thay đổi nội dung.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function handleCancel(id) {
    if (confirm('Bạn có chắc chắn muốn hủy đề xuất này? Thao tác này sẽ xóa vĩnh viễn đề xuất khi chưa được duyệt.')) {
        window.location.href = 'delete.php?id=' + id;
    }
}
</script>

<?php 
require_once '../../includes/footer.php'; 
?>