<?php
/**
 * File: modules/reports/create.php
 * Chức năng: Nhân viên lập báo cáo định kỳ có đính kèm tệp.
 */

// 1. Nhúng Header
require_once '../../includes/header.php';

$success = '';
$error = '';

// 2. Xử lý khi nhấn nút "Gửi báo cáo"
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $content = clean_input($_POST['content']);
    $userId = $_SESSION['userId'];
    $status = 'Submitted';
    $attachment_name = null;

    if (empty($content)) {
        $error = "Nội dung báo cáo không được để trống!";
    } else {
        try {
            // Xử lý Upload File nếu có
            if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
                $fileTmpPath = $_FILES['attachment']['tmp_name'];
                $fileName = basename($_FILES['attachment']['name']);
                
                // Sử dụng đường dẫn tuyệt đối dựa trên thư mục hiện tại của file create.php
                $uploadFileDir = dirname(dirname(__DIR__)) . '/uploads/reports/';
                
                // Tự động tạo thư mục nếu chưa tồn tại
                if (!is_dir($uploadFileDir)) {
                    if (!mkdir($uploadFileDir, 0777, true)) {
                        throw new Exception("Không thể tạo thư mục upload. Hãy kiểm tra quyền ghi trên macOS.");
                    }
                }

                $newFileName = time() . '_' . $fileName;
                $dest_path = $uploadFileDir . $newFileName;
                
                if (move_uploaded_file($fileTmpPath, $dest_path)) {
                    $attachment_name = $newFileName;
                } else {
                    throw new Exception("Lỗi: Server không có quyền ghi vào thư mục. Hãy chạy lệnh 'chmod -R 777 uploads' trong Terminal.");
                }
            }

            $pdo->beginTransaction();

            $sql = "INSERT INTO Report (content, status, attachment, createdBy, createdDate) 
                    VALUES (:content, :status, :attachment, :createdBy, NOW())";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':content'    => $content,
                ':status'     => $status,
                ':attachment' => $attachment_name,
                ':createdBy'  => $userId
            ]);

            $stmt_mgr = $pdo->query("SELECT userId FROM User WHERE role = 'Manager' LIMIT 1");
            $managerId = $stmt_mgr->fetchColumn();
            
            if ($managerId) {
                $msg = "Nhân viên " . $_SESSION['name'] . " vừa nộp báo cáo mới.";
                send_notification($pdo, $managerId, $msg);
            }

            $pdo->commit();
            $success = "Báo cáo của bạn đã được gửi thành công!";
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = $e->getMessage();
        }
    }
}
?>

<div class="container-fluid py-4" style="background-color: #f8fafc; min-height: 100vh;">
    <div class="row">
        <?php include '../../includes/sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="mx-auto" style="max-width: 900px;">
                <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
                    <h4 class="fw-bold mb-0 text-dark"><i class="fa-solid fa-pen-to-square text-primary me-2"></i>Lập báo cáo công việc</h4>
                </div>

                <div class="card shadow-sm border-0" style="border-radius: 15px;">
                    <div class="card-body p-4">
                        <?php if ($success): ?>
                            <div class="alert alert-success border-0 shadow-sm mb-4">
                                <i class="fa-solid fa-circle-check me-2"></i><?php echo $success; ?>
                                <a href="my_reports.php" class="alert-link ms-2 small">Xem danh sách báo cáo →</a>
                            </div>
                        <?php endif; ?>

                        <?php if ($error): ?>
                            <div class="alert alert-danger border-0 shadow-sm mb-4">
                                <i class="fa-solid fa-circle-exclamation me-2"></i><?php echo $error; ?>
                            </div>
                        <?php endif; ?>

                        <form action="" method="POST" enctype="multipart/form-data">
                            <div class="mb-4">
                                <label class="form-label fw-bold small text-muted">TỔNG HỢP CÔNG VIỆC VÀ KẾT QUẢ <span class="text-danger">*</span></label>
                                <textarea name="content" class="form-control border-2" rows="8" 
                                          placeholder="Nhập chi tiết các task đã thực hiện..." required style="border-radius: 10px;"></textarea>
                            </div>

                            <div class="mb-4">
                                <label class="form-label fw-bold small text-muted text-uppercase">Tệp đính kèm (Hình ảnh, Tài liệu...)</label>
                                <div class="input-group">
                                    <input type="file" name="attachment" class="form-control border-2" id="attachment" style="border-radius: 10px;">
                                </div>
                                <div class="form-text small italic">Hỗ trợ các định dạng: .jpg, .png, .pdf, .xlsx (Tối đa 5MB)</div>
                            </div>

                            <div class="d-flex justify-content-between align-items-center border-top pt-4">
                                <span class="text-muted small">Người lập: <strong><?php echo htmlspecialchars($_SESSION['name']); ?></strong></span>
                                <div class="btn-group">
                                    <a href="my_reports.php" class="btn btn-light px-4 rounded-pill me-2">Hủy bỏ</a>
                                    <button type="submit" class="btn btn-primary px-5 rounded-pill shadow">
                                        Nộp báo cáo <i class="fa-solid fa-paper-plane ms-2"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>