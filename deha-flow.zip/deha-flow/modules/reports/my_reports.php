<?php
/**
 * File: modules/reports/my_reports.php
 */
require_once '../../includes/header.php';

$userId = $_SESSION['userId'];
$role = $_SESSION['role'];

try {
    if ($role === 'Manager') {
        // PM xem tất cả báo cáo của nhân viên
        $sql = "SELECT r.*, u.name as employee_name 
                FROM Report r 
                JOIN User u ON r.createdBy = u.userId 
                ORDER BY CASE 
                    WHEN LOWER(r.status) = 'submitted' THEN 0 
                    WHEN LOWER(r.status) = 'pending' THEN 0 
                    ELSE 1 END, r.createdDate DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
    } else {
        // Nhân viên xem báo cáo cá nhân
        $sql = "SELECT r.*, u.name as reviewer_name 
                FROM Report r 
                LEFT JOIN User u ON r.reviewedBy = u.userId 
                WHERE r.createdBy = :userId 
                ORDER BY r.createdDate DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':userId' => $userId]);
    }
    $reports = $stmt->fetchAll();
} catch (Exception $e) {
    die("Lỗi hệ thống: " . $e->getMessage());
}
?>

<div class="container-fluid" style="background-color: #f8fafc; min-height: 100vh;">
    <div class="row">
        <?php include '../../includes/sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-4">
            <div class="mx-auto" style="max-width: 1100px;">
                
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="fw-bold text-dark mb-0">
                        <i class="fa-solid fa-clipboard-check text-primary me-2"></i>
                        <?php echo ($role === 'Manager') ? 'Phê duyệt báo cáo nhân viên' : 'Lịch sử báo cáo cá nhân'; ?>
                    </h4>
                    
                    <div class="btn-group">
                        <?php if ($role === 'Employee'): ?>
                            <a href="create.php" class="btn btn-primary fw-bold shadow-sm px-4 rounded-pill">
                                <i class="fa-solid fa-plus me-2"></i>Tạo báo cáo mới
                            </a>
                        <?php endif; ?>

                        <!-- NÚT TẠO BÁO CÁO TỔNG HỢP DÀNH CHO QUẢN LÝ -->
                        <?php if ($role === 'Manager'): ?>
                            <a href="create_summary.php" class="btn btn-success fw-bold shadow-sm px-4 rounded-pill">
                                <i class="fa-solid fa-file-signature me-2"></i>Tạo báo cáo tổng hợp
                            </a>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if (isset($_GET['success_id'])): ?>
                    <div class="alert alert-<?php echo (strtolower($_GET['action_type']) === 'approved' || strtolower($_GET['action_type']) === 'summary') ? 'success' : 'danger'; ?> border-0 shadow-sm mb-4 d-flex align-items-center" style="border-radius: 12px;">
                        <i class="fa-solid fa-circle-check fa-lg me-3"></i>
                        <div>
                            <?php if ($_GET['action_type'] === 'summary'): ?>
                                Báo cáo tổng hợp đã được gửi lên cấp trên thành công!
                            <?php else: ?>
                                Báo cáo <strong>#<?php echo htmlspecialchars($_GET['success_id']); ?></strong> đã được 
                                <strong><?php echo (strtolower($_GET['action_type']) === 'approved') ? 'phê duyệt thành công' : 'từ chối xử lý'; ?></strong>. 
                                Thông báo đã gửi tới nhân viên.
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="card border-0 shadow-sm" style="border-radius: 15px; overflow: hidden;">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light text-muted small text-uppercase fw-bold">
                                <tr>
                                    <th class="ps-4 py-3">Mã số</th>
                                    <th class="py-3"><?php echo ($role === 'Manager') ? 'Nhân viên nộp' : 'Nội dung'; ?></th>
                                    <th class="py-3 text-center">Ngày nộp</th>
                                    <th class="py-3 text-center">Trạng thái</th>
                                    <th class="pe-4 py-3 text-end">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($reports as $r): ?>
                                    <tr>
                                        <td class="ps-4 fw-bold text-primary">#<?php echo $r['reportId']; ?></td>
                                        <td>
                                            <div class="fw-bold text-dark">
                                                <?php echo ($role === 'Manager') ? htmlspecialchars($r['employee_name']) : htmlspecialchars(substr($r['content'], 0, 50)) . '...'; ?>
                                            </div>
                                        </td>
                                        <td class="text-center small text-secondary"><?php echo date('H:i d/m/Y', strtotime($r['createdDate'])); ?></td>
                                        <td class="text-center">
                                            <?php 
                                                $st = strtolower(trim($r['status']));
                                                if ($st === 'approved') {
                                                    echo '<span class="badge rounded-pill bg-success px-3 py-2">Đã duyệt</span>';
                                                } elseif ($st === 'rejected') {
                                                    echo '<span class="badge rounded-pill bg-danger px-3 py-2">Từ chối</span>';
                                                } else {
                                                    echo '<span class="badge rounded-pill bg-warning text-dark px-3 py-2">Chờ duyệt</span>';
                                                }
                                            ?>
                                        </td>
                                        <td class="pe-4 text-end">
                                            <a href="view_detail.php?id=<?php echo $r['reportId']; ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3 fw-bold">Chi tiết</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<?php require_once '../../includes/footer.php'; ?>