<?php
/**
 * File: modules/reports/manage.php
 * Chức năng: Quản lý xem, duyệt và tổng hợp báo cáo của nhân viên.
 * Ánh xạ: Mục 3.1.3 (R3.2 Xử lý báo cáo) và Mục 3.2.1 c (Use Case Báo cáo - Quản lý).
 */

// 1. Nhúng Header (Bao gồm kết nối CSDL và Phân quyền)
require_once '../../includes/header.php';

// Bảo mật: Chỉ Quản lý mới có quyền truy cập (Mục 3.1.4 c)
if (!is_manager()) {
    header('Location: ../../index.php');
    exit();
}

$success = '';
$error = '';

// 2. Xử lý logic Duyệt/Từ chối báo cáo (Mã giả mục 3.3.4 a)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['report_id'])) {
    $reportId = $_POST['report_id'];
    $action = $_POST['action']; // 'Approved' hoặc 'Rejected' (Cần sửa)
    $reviewerId = $_SESSION['userId'];

    try {
        $sql = "UPDATE Report SET status = :status, reviewedBy = :reviewer WHERE reportId = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':status' => $action,
            ':reviewer' => $reviewerId,
            ':id' => $reportId
        ]);

        // Gửi thông báo cho nhân viên về kết quả báo cáo (NotificationService)
        $status_msg = ($action === 'Approved') ? "đã được duyệt" : "cần được chỉnh sửa lại";
        $msg = "Báo cáo mã #" . $reportId . " của bạn " . $status_msg;
        
        // Tìm userId người tạo báo cáo
        $stmt_owner = $pdo->prepare("SELECT createdBy FROM Report WHERE reportId = ?");
        $stmt_owner->execute([$reportId]);
        $ownerId = $stmt_owner->fetchColumn();
        
        send_notification($pdo, $ownerId, $msg);

        $success = "Đã cập nhật trạng thái báo cáo thành công!";
    } catch (Exception $e) {
        $error = "Lỗi: " . $e->getMessage();
    }
}

// 3. Lấy danh sách báo cáo cần xử lý và đã xử lý
try {
    $sql = "SELECT r.*, u.name as employee_name, u.department 
            FROM Report r 
            JOIN User u ON r.createdBy = u.userId 
            ORDER BY r.createdDate DESC";
    $reports = $pdo->query($sql)->fetchAll();
} catch (Exception $e) {
    die("Lỗi tải dữ liệu: " . $e->getMessage());
}
?>

<div class="row">
    <?php include '../../includes/sidebar.php'; ?>

    <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2"><i class="fa-solid fa-list-check text-primary me-2"></i>Quản lý & Duyệt báo cáo</h1>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success border-0 shadow-sm mb-4"><i class="fa-solid fa-check-circle me-2"></i><?php echo $success; ?></div>
        <?php endif; ?>

        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h6 class="mb-0 fw-bold text-uppercase small text-muted">Danh sách báo cáo toàn công ty</h6>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th class="ps-4">Nhân viên</th>
                                <th>Phòng ban</th>
                                <th>Nội dung báo cáo</th>
                                <th>Ngày nộp</th>
                                <th>Trạng thái</th>
                                <th class="text-end pe-4">Xử lý</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($reports as $r): ?>
                            <tr>
                                <td class="ps-4">
                                    <div class="fw-bold"><?php echo htmlspecialchars($r['employee_name']); ?></div>
                                    <small class="text-muted">#<?php echo $r['reportId']; ?></small>
                                </td>
                                <td><span class="badge bg-light text-dark border"><?php echo htmlspecialchars($r['department']); ?></span></td>
                                <td>
                                    <div class="text-truncate" style="max-width: 250px;" title="<?php echo htmlspecialchars($r['content']); ?>">
                                        <?php echo htmlspecialchars($r['content']); ?>
                                    </div>
                                </td>
                                <td><small><?php echo format_date($r['createdDate']); ?></small></td>
                                <td><?php echo get_status_badge($r['status']); ?></td>
                                <td class="text-end pe-4">
                                    <?php if ($r['status'] === 'Submitted'): ?>
                                    <form action="" method="POST" class="d-inline">
                                        <input type="hidden" name="report_id" value="<?php echo $r['reportId']; ?>">
                                        <button type="submit" name="action" value="Rejected" class="btn btn-sm btn-outline-danger rounded-pill" title="Yêu cầu sửa lại">
                                            <i class="fa-solid fa-rotate-left"></i>
                                        </button>
                                        <button type="submit" name="action" value="Approved" class="btn btn-sm btn-success rounded-pill px-3" title="Duyệt báo cáo">
                                            <i class="fa-solid fa-check"></i> Duyệt
                                        </button>
                                    </form>
                                    <?php else: ?>
                                        <button class="btn btn-sm btn-light rounded-pill px-3" disabled>Đã xử lý</button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Section: Tổng hợp báo cáo (KPI - Mục 3.1.3 R4.1.3) -->
        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card border-0 shadow-sm bg-primary text-white">
                    <div class="card-body">
                        <h6 class="text-uppercase small fw-bold opacity-75">Hiệu suất nộp báo cáo</h6>
                        <h2 class="fw-bold mb-0">95%</h2>
                        <p class="small mb-0 mt-2">Dựa trên tổng số nhân sự DEHA Việt Nam[cite: 1]</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card border-0 shadow-sm bg-white">
                    <div class="card-body d-flex align-items-center">
                        <div class="flex-grow-1">
                            <h6 class="text-uppercase small fw-bold text-muted">Báo cáo chờ duyệt</h6>
                            <h2 class="fw-bold mb-0 text-danger">
                                <?php 
                                    $stmt_count = $pdo->query("SELECT COUNT(*) FROM Report WHERE status = 'Submitted'");
                                    echo $stmt_count->fetchColumn();
                                ?>
                            </h2>
                        </div>
                        <i class="fa-solid fa-file-circle-exclamation fa-3x text-danger opacity-25"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>