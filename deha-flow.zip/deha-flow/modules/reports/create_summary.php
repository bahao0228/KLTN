<?php
/**
 * File: modules/reports/create_summary.php
 * Chức năng: Quản lý tạo báo cáo tổng hợp gửi cấp trên.
 */
require_once '../../includes/header.php';

// Bảo vệ quyền truy cập: Chỉ Manager mới được vào
if ($_SESSION['role'] !== 'Manager') {
    header("Location: ../../index.php");
    exit();
}

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $content = clean_input($_POST['content']);
    $userId = $_SESSION['userId'];
    $status = 'Submitted'; 
    $attachment_name = null;

    if (empty($content)) {
        $error = "Nội dung báo cáo tổng hợp không được để trống!";
    } else {
        try {
            // Xử lý upload file vào uploads/reports/
            if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
                $fileTmpPath = $_FILES['attachment']['tmp_name'];
                $fileName = basename($_FILES['attachment']['name']);
                
                // Sử dụng đường dẫn tuyệt đối để tránh lỗi trên macOS XAMPP
                $uploadFileDir = dirname(dirname(__DIR__)) . '/uploads/reports/';
                
                if (!is_dir($uploadFileDir)) {
                    mkdir($uploadFileDir, 0777, true);
                }

                $newFileName = time() . '_summary_' . $fileName;
                $dest_path = $uploadFileDir . $newFileName;
                
                if (move_uploaded_file($fileTmpPath, $dest_path)) {
                    $attachment_name = $newFileName;
                } else {
                    throw new Exception("Lỗi: Không thể ghi file vào thư mục. Hãy chạy lệnh 'chmod -R 777 uploads' trong Terminal.");
                }
            }

            $pdo->beginTransaction();

            $sql = "INSERT INTO Report (content, status, attachment, createdBy, createdDate) 
                    VALUES (:content, :status, :attachment, :createdBy, NOW())";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':content'    => $content,
                ':status'     => $status,
                ':attachment' => $attachment_name,
                ':createdBy'  => $userId
            ]);

            $pdo->commit();
            // Điều hướng về danh sách với thông báo thành công
            header("Location: my_reports.php?success_id=0&action_type=summary");
            exit();
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = $e->getMessage();
        }
    }
}
?>

<div class="container-fluid py-4" style="background-color: #f8fafc; min-height: 100vh;">
    <div class="row">
        <?php include '../../includes/sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="mx-auto" style="max-width: 900px;">
                <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
                    <h4 class="fw-bold mb-0 text-dark">
                        <i class="fa-solid fa-file-signature text-success me-2"></i>Lập báo cáo tổng hợp gửi cấp trên
                    </h4>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0 small">
                            <li class="breadcrumb-item"><a href="my_reports.php" class="text-decoration-none">Danh sách</a></li>
                            <li class="breadcrumb-item active">Tổng hợp</li>
                        </ol>
                    </nav>
                </div>

                <div class="card shadow-sm border-0" style="border-radius: 15px;">
                    <div class="card-body p-4">
                        <?php if ($error): ?>
                            <div class="alert alert-danger border-0 shadow-sm mb-4" style="border-radius: 10px;">
                                <i class="fa-solid fa-circle-exclamation me-2"></i><?php echo $error; ?>
                            </div>
                        <?php endif; ?>

                        <form action="" method="POST" enctype="multipart/form-data">
                            <div class="mb-4">
                                <label class="form-label fw-bold small text-muted">NỘI DUNG TỔNG HỢP <span class="text-danger">*</span></label>
                                <textarea name="content" class="form-control border-2" rows="10" 
                                          placeholder="Tóm tắt kết quả làm việc của đội ngũ và các đề xuất lên cấp trên..." required style="border-radius: 10px;"></textarea>
                                <div class="form-text mt-2 small">
                                    <i class="fa-solid fa-circle-info text-primary me-1"></i> 
                                    Báo cáo này sẽ được lưu trữ dưới quyền Quản lý của bạn.
                                </div>
                            </div>

                            <div class="mb-4">
                                <label class="form-label fw-bold small text-muted text-uppercase">Tài liệu đính kèm (nếu có)</label>
                                <div class="input-group">
                                    <input type="file" name="attachment" class="form-control border-2" id="attachment" style="border-radius: 10px;">
                                </div>
                                <div class="form-text small italic">Hỗ trợ các định dạng tài liệu, bảng tính hoặc hình ảnh.</div>
                            </div>

                            <div class="d-flex justify-content-between align-items-center border-top pt-4">
                                <span class="text-muted small italic">Người lập: <strong><?php echo htmlspecialchars($_SESSION['name']); ?></strong> (Manager)</span>
                                <div class="btn-group">
                                    <a href="my_reports.php" class="btn btn-light px-4 rounded-pill me-2">Quay lại</a>
                                    <button type="submit" class="btn btn-success px-5 rounded-pill shadow">
                                        Gửi tổng hợp <i class="fa-solid fa-paper-plane ms-2"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>