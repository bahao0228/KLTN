<?php
/**
 * File: modules/reports/view_detail.php
 */
require_once '../../includes/header.php';

$reportId = $_GET['id'] ?? null;
$userId = $_SESSION['userId'];
$role = $_SESSION['role'];

if (!$reportId) { header('Location: my_reports.php'); exit(); }

try {
    $stmt = $pdo->prepare("SELECT r.*, u.name as employee_name FROM Report r JOIN User u ON r.createdBy = u.userId WHERE r.reportId = ?");
    $stmt->execute([$reportId]);
    $report = $stmt->fetch();
    if (!$report) { die("Không tìm thấy báo cáo."); }
} catch (Exception $e) { die("Lỗi: " . $e->getMessage()); }

// Xử lý phê duyệt/từ chối của Manager
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $role === 'Manager') {
    $action = $_POST['action']; 
    $comment = clean_input($_POST['review_comment']);
    try {
        $pdo->beginTransaction();
        $sql = "UPDATE Report SET status = ?, reviewedBy = ?, review_comment = ? WHERE reportId = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$action, $userId, $comment, $reportId]);
        send_notification($pdo, $report['createdBy'], "Báo cáo #$reportId của bạn đã được $action.");
        $pdo->commit();
        header("Location: my_reports.php?success_id=$reportId&action_type=$action");
        exit();
    } catch (Exception $e) { $pdo->rollBack(); die($e->getMessage()); }
}
?>

<div class="container-fluid py-4" style="background-color: #f8fafc; min-height: 100vh;">
    <div class="row">
        <?php include '../../includes/sidebar.php'; ?>
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="mx-auto" style="max-width: 800px;">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="fw-bold mb-0">Chi tiết báo cáo #<?php echo $reportId; ?></h4>
                    <a href="my_reports.php" class="btn btn-outline-secondary btn-sm rounded-pill px-3 shadow-sm">Quay lại</a>
                </div>

                <div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
                    <div class="card-body p-4">
                        <div class="row mb-4">
                            <div class="col-md-6 fw-bold text-dark"><i class="fa-solid fa-user-circle me-2 text-primary"></i><?php echo htmlspecialchars($report['employee_name']); ?></div>
                            <div class="col-md-6 text-md-end text-secondary small"><?php echo date('H:i - d/m/Y', strtotime($report['createdDate'])); ?></div>
                        </div>
                        
                        <!-- Hiển thị nội dung báo cáo -->
                        <div class="p-4 bg-light rounded-3 border text-dark mb-4" style="white-space: pre-wrap; min-height: 100px;">
                            <?php echo htmlspecialchars($report['content']); ?>
                        </div>

                        <!-- KHU VỰC HIỂN THỊ TỆP ĐÍNH KÈM -->
                        <div class="mt-3 pt-3 border-top">
                            <label class="small text-muted text-uppercase fw-bold d-block mb-3">
                                <i class="fa-solid fa-paperclip me-1"></i> Tệp đính kèm
                            </label>
                            <?php if (!empty($report['attachment'])): ?>
                                <?php 
                                    $file_name = $report['attachment'];
                                    $file_path = "../../uploads/reports/" . $file_name;
                                    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                                    $image_exts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                                ?>
                                <div class="d-flex align-items-center p-3 border rounded-3 bg-white shadow-sm" style="max-width: 450px;">
                                    <?php if (in_array($file_ext, $image_exts)): ?>
                                        <div class="me-3">
                                            <a href="<?php echo $file_path; ?>" target="_blank">
                                                <img src="<?php echo $file_path; ?>" class="rounded shadow-sm" style="width: 60px; height: 60px; object-fit: cover; border: 1px solid #eee;">
                                            </a>
                                        </div>
                                    <?php else: ?>
                                        <div class="me-3 bg-light rounded d-flex align-items-center justify-content-center" style="width: 60px; height: 60px;">
                                            <i class="fa-solid fa-file-pdf fa-2x text-danger"></i>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="overflow-hidden">
                                        <div class="text-dark fw-bold small text-truncate mb-1" title="<?php echo htmlspecialchars($file_name); ?>">
                                            <?php echo htmlspecialchars($file_name); ?>
                                        </div>
                                        <a href="<?php echo $file_path; ?>" download class="btn btn-sm btn-primary py-0 px-3 rounded-pill" style="font-size: 0.7rem;">
                                            <i class="fa-solid fa-download me-1"></i> Tải xuống
                                        </a>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="text-muted small fst-italic">Báo cáo này không có tệp đính kèm.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Form phê duyệt (Manager) hoặc Kết quả (Employee) -->
                <?php 
                $st = strtolower(trim($report['status']));
                if ($role === 'Manager' && $st !== 'approved' && $st !== 'rejected'): 
                ?>
                <div class="card border-0 shadow border-top border-primary border-4" style="border-radius: 15px;">
                    <div class="card-body p-4 text-center">
                        <h5 class="fw-bold mb-3">Phê duyệt báo cáo</h5>
                        <form action="" method="POST">
                            <textarea name="review_comment" class="form-control border-2 mb-3" rows="3" placeholder="Nhập phản hồi..." required></textarea>
                            <div class="d-flex gap-3 justify-content-center">
                                <button type="submit" name="action" value="rejected" class="btn btn-outline-danger px-4 rounded-pill fw-bold">Từ chối</button>
                                <button type="submit" name="action" value="approved" class="btn btn-success px-5 rounded-pill fw-bold shadow">Phê duyệt</button>
                            </div>
                        </form>
                    </div>
                </div>
                <?php elseif ($st === 'approved' || $st === 'rejected'): ?>
                <div class="alert <?php echo ($st === 'approved') ? 'alert-success' : 'alert-danger'; ?> border-0 shadow-sm p-4" style="border-radius: 15px;">
                    <h6 class="fw-bold mb-2">Trạng thái: <?php echo ($st === 'approved') ? 'Đã duyệt' : 'Từ chối'; ?></h6>
                    <?php if(!empty($report['review_comment'])): ?>
                        <div class="small fst-italic">"<?php echo htmlspecialchars($report['review_comment']); ?>"</div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</div>
<?php require_once '../../includes/footer.php'; ?>