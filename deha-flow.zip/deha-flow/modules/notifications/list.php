<?php
/**
 * File: modules/notifications/list.php
 * Chức năng: Hiển thị danh sách thông báo của người dùng.
 */

require_once '../../includes/header.php';

$userId = $_SESSION['userId'];
$current_page = 'notifications/list.php';

// 1. Lấy danh sách thông báo từ DB
$stmt = $pdo->prepare("SELECT * FROM Notification WHERE userId = ? ORDER BY createdDate DESC");
$stmt->execute([$userId]);
$notifications = $stmt->fetchAll();

// 2. Đánh dấu tất cả là đã đọc khi người dùng vào trang này
$stmt_update = $pdo->prepare("UPDATE Notification SET isRead = 1 WHERE userId = ?");
$stmt_update->execute([$userId]);
?>

<div class="container-fluid" style="background-color: #f8f9fa; min-height: 100vh;">
    <div class="row">
        <?php include '../../includes/sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-4 d-flex flex-column align-items-center">
            <div style="width: 100%; max-width: 800px;">
                
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="fw-bold mb-0 text-dark">
                        <i class="fa-solid fa-bell text-warning me-2"></i>Thông báo của tôi
                    </h4>
                </div>

                <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                    <div class="list-group list-group-flush">
                        <?php if (count($notifications) > 0): ?>
                            <?php foreach ($notifications as $noti): ?>
                                <div class="list-group-item list-group-item-action p-3 border-start border-4 <?php echo $noti['isRead'] ? 'border-light' : 'border-primary bg-light-subtle'; ?>">
                                    <div class="d-flex w-100 justify-content-between align-items-center">
                                        <div class="pe-3">
                                            <p class="mb-1 text-dark <?php echo $noti['isRead'] ? '' : 'fw-bold'; ?>" style="font-size: 0.95rem;">
                                                <?php echo htmlspecialchars($noti['message']); ?>
                                            </p>
                                            <small class="text-muted">
                                                <i class="fa-regular fa-clock me-1"></i>
                                                <?php echo date('d/m/Y H:i', strtotime($noti['createdDate'])); ?>
                                            </small>
                                        </div>
                                        <?php if (!$noti['isRead']): ?>
                                            <span class="badge rounded-pill bg-primary px-2 py-1" style="font-size: 0.65rem;">Mới</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <i class="fa-solid fa-bell-slash fa-3x mb-3 text-muted opacity-25"></i>
                                <p class="text-muted italic">Bạn chưa có thông báo nào.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<style>
/* Hiệu ứng hover cho danh sách thông báo */
.list-group-item-action:hover {
    background-color: #f1f3f5 !important;
    cursor: pointer;
}
.bg-light-subtle {
    background-color: rgba(13, 110, 253, 0.05) !important;
}
</style>

<?php require_once '../../includes/footer.php'; ?>