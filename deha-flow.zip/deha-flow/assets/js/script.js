/**
 * File: script.js
 * Chức năng: Xử lý tương tác Frontend (Xác nhận xóa, ẩn thông báo).
 */

document.addEventListener("DOMContentLoaded", function () {
  // 1. Tự động ẩn các thông báo (Alert) sau 5 giây
  const alerts = document.querySelectorAll(".alert");
  alerts.forEach(function (alert) {
    setTimeout(function () {
      const bsAlert = new bootstrap.Alert(alert);
      bsAlert.close();
    }, 5000);
  });

  // 2. Xác nhận trước khi thực hiện các hành động quan trọng
  const confirmButtons = document.querySelectorAll(".btn-confirm");
  confirmButtons.forEach((button) => {
    button.addEventListener("click", function (e) {
      if (!confirm("Bạn có chắc chắn muốn thực hiện hành động này?")) {
        e.preventDefault();
      }
    });
  });
});
