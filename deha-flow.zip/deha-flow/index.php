<?php
/**
 * File: index.php
 * Chức năng: Trang Dashboard chính - Tổng hợp dữ liệu thống kê.
 */

// 1. Nhúng Header (đã bao gồm kết nối CSDL và kiểm tra đăng nhập)
require_once 'includes/header.php';

// 2. Lấy dữ liệu thống kê dựa trên vai trò
$userId = $_SESSION['userId'];
$role = $_SESSION['role'];

// --- PHẦN XỬ LÝ THÔNG BÁO ---
$msg = $_GET['msg'] ?? '';
$alert_html = '';
if ($msg === 'updated') {
    $alert_html = '<div class="alert alert-success alert-dismissible fade show border-0 shadow-sm mb-4" role="alert">
                        <i class="fa-solid fa-check-circle me-2"></i> <strong>Thành công!</strong> Đề xuất đã được cập nhật nội dung mới.
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                   </div>';
} elseif ($msg === 'cancelled') {
    $alert_html = '<div class="alert alert-warning alert-dismissible fade show border-0 shadow-sm mb-4" role="alert">
                        <i class="fa-solid fa-trash-can me-2"></i> <strong>Đã hủy!</strong> Đề xuất đã được xóa khỏi hệ thống.
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                   </div>';
}
// ----------------------------

// Thống kê Đề xuất (Bảng Proposal)
$stmt_proposals = $pdo->prepare("SELECT COUNT(*) FROM Proposal " . ($role !== 'Manager' ? "WHERE createdBy = ?" : ""));
$role !== 'Manager' ? $stmt_proposals->execute([$userId]) : $stmt_proposals->execute();
$total_proposals = $stmt_proposals->fetchColumn();

// Thống kê Công việc đang làm (Bảng Task - Trạng thái Doing)
$stmt_tasks = $pdo->prepare("SELECT COUNT(*) FROM Task WHERE status = 'Doing' " . ($role !== 'Manager' ? "AND assignedTo = ?" : ""));
$role !== 'Manager' ? $stmt_tasks->execute([$userId]) : $stmt_tasks->execute();
$doing_tasks = $stmt_tasks->fetchColumn();

// Thống kê Báo cáo đã nộp (Bảng Report)
$stmt_reports = $pdo->prepare("SELECT COUNT(*) FROM Report " . ($role !== 'Manager' ? "WHERE createdBy = ?" : ""));
$role !== 'Manager' ? $stmt_reports->execute([$userId]) : $stmt_reports->execute();
$total_reports = $stmt_reports->fetchColumn();
?>

<div class="row">
    <!-- Nạp Sidebar điều hướng chuyên sâu -->
    <?php include 'includes/sidebar.php'; ?>

    <!-- Nội dung chính Dashboard -->
    <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Bảng điều khiển</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
                <span class="badge bg-primary p-2">
                    <i class="fa-regular fa-calendar-days me-1"></i> Hôm nay: <?php echo date('d/m/Y'); ?>
                </span>
            </div>
        </div>

        <!-- HIỂN THỊ THÔNG BÁO TẠI ĐÂY -->
        <?php echo $alert_html; ?>

        <!-- Section 1: Thẻ thống kê (Stats Cards) -->
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card border-0 shadow-sm overflow-hidden h-100">
                    <div class="card-body p-4 border-start border-primary border-5">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0 bg-primary bg-opacity-10 p-3 rounded-circle text-primary">
                                <i class="fa-solid fa-file-invoice fa-2x"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="text-muted mb-1 small text-uppercase fw-bold">Tổng đề xuất</h6>
                                <h3 class="mb-0 fw-bold"><?php echo $total_proposals; ?></h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="card border-0 shadow-sm overflow-hidden h-100">
                    <div class="card-body p-4 border-start border-warning border-5">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0 bg-warning bg-opacity-10 p-3 rounded-circle text-warning">
                                <i class="fa-solid fa-spinner fa-2x"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="text-muted mb-1 small text-uppercase fw-bold">Việc đang làm</h6>
                                <h3 class="mb-0 fw-bold"><?php echo $doing_tasks; ?></h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="card border-0 shadow-sm overflow-hidden h-100">
                    <div class="card-body p-4 border-start border-success border-5">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0 bg-success bg-opacity-10 p-3 rounded-circle text-success">
                                <i class="fa-solid fa-clipboard-check fa-2x"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="text-muted mb-1 small text-uppercase fw-bold">Báo cáo đã gửi</h6>
                                <h3 class="mb-0 fw-bold"><?php echo $total_reports; ?></h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section 2: Hoạt động gần đây hoặc Lối tắt nhanh -->
        <div class="row mt-2">
            <div class="col-lg-8">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
                        <span class="fw-bold"><i class="fa-solid fa-clock-rotate-left me-2 text-primary"></i>Hoạt động gần đây</span>
                        <a href="#" class="btn btn-sm btn-link text-decoration-none small">Xem tất cả</a>
                    </div>
                    <div class="card-body p-0">
                        <div class="list-group list-group-flush">
                            <div class="list-group-item p-4 border-0 border-bottom">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1 fw-bold text-primary">Hệ thống sẵn sàng!</h6>
                                    <small class="text-muted">Vừa xong</small>
                                </div>
                                <p class="mb-1 small text-muted">Chào mừng bạn đến với hệ thống DEHA VIỆT NAM. Hãy bắt đầu bằng cách tạo đề xuất mới hoặc kiểm tra công việc được giao.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card bg-primary text-white border-0 shadow-sm">
                    <div class="card-body p-4 text-center">
                        <i class="fa-solid fa-bolt-lightning fa-3x mb-3 opacity-50"></i>
                        <h5 class="fw-bold">Thao tác nhanh</h5>
                        <p class="small opacity-75">Sử dụng các lối tắt bên dưới để tối ưu hiệu suất công việc.</p>
                        <div class="d-grid gap-2 mt-4">
                            <a href="modules/proposals/create.php" class="btn btn-light text-primary fw-bold">Tạo đề xuất mới</a>
                            <a href="modules/reports/create.php" class="btn btn-outline-light border-2">Gửi báo cáo ngay</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// 3. Nhúng Footer
require_once 'includes/footer.php';
?>